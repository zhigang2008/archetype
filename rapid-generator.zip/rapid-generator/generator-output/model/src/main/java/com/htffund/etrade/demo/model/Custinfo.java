/*
 * Author: [Your Name]
 * Since :  2015-09-266
 * Copyright: www.99fund.com 
 */
package com.htffund.etrade.demo.model;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.springframework.format.annotation.DateTimeFormat;

/**
 * @author [Your Name]
 * @version 1.0
 * @since 1.0
 */
 public class Custinfo implements java.io.Serializable{
	private static final long serialVersionUID = 5454155825314635342L; //请重新生成
	
	//date formats
	public static final String FORMAT_LOGINTIME = "yyyy-MM-dd"; // DateTime : "yyyy-MM-dd HH:mm:ss"
	public static final String FORMAT_UPDATETIMESTAMP = "yyyy-MM-dd"; // DateTime : "yyyy-MM-dd HH:mm:ss"
	
	/** 客户编号 */
	private java.lang.String custno;
	/** 投资人类别 */
	private java.lang.String invtp;
	/** 客户名称 */
	private java.lang.String invnm;
	/** 证件类型 */
	private java.lang.String idtp;
	/** 证件号码 */
	private java.lang.String idno;
	/** 手机 */
	private java.lang.String mobileno;
	/** 电子邮件 */
	private java.lang.String email;
	/** 状态'N'正常 'C'撤销 */
	private java.lang.String custst;
	/** 交易密码 */
	private java.lang.String passwd;
	/** 上次登录时间 */
	@DateTimeFormat(pattern="yyyy-MM-dd") //请调整为该属性适应的日期格式
	//@JsonFormat(pattern="yyyy-MM-dd")
	private java.util.Date logintime;
	/** 登入总次数 */
	private java.lang.Integer logincount;
	/** 密码错误次数 */
	private Integer passwderr;
	/** 开户日期 */
	private java.lang.String opendt;
	/** 更新时间戳 */
	@DateTimeFormat(pattern="yyyy-MM-dd") //请调整为该属性适应的日期格式
	//@JsonFormat(pattern="yyyy-MM-dd")
	private java.util.Date updatetimestamp;
	/** 客户ID */
	private java.math.BigDecimal custid;
	/** 交易密码 */
	private java.lang.String tradepwd;

	public Custinfo(){
	}

	public Custinfo(	java.lang.String custno){
		this.custno = custno;
	}
	public void setCustno(java.lang.String custno) {
		this.custno = custno;
	}
	
	public java.lang.String getCustno() {
		return this.custno;
	}
	public void setInvtp(java.lang.String invtp) {
		this.invtp = invtp;
	}
	
	public java.lang.String getInvtp() {
		return this.invtp;
	}
	public void setInvnm(java.lang.String invnm) {
		this.invnm = invnm;
	}
	
	public java.lang.String getInvnm() {
		return this.invnm;
	}
	public void setIdtp(java.lang.String idtp) {
		this.idtp = idtp;
	}
	
	public java.lang.String getIdtp() {
		return this.idtp;
	}
	public void setIdno(java.lang.String idno) {
		this.idno = idno;
	}
	
	public java.lang.String getIdno() {
		return this.idno;
	}
	public void setMobileno(java.lang.String mobileno) {
		this.mobileno = mobileno;
	}
	
	public java.lang.String getMobileno() {
		return this.mobileno;
	}
	public void setEmail(java.lang.String email) {
		this.email = email;
	}
	
	public java.lang.String getEmail() {
		return this.email;
	}
	public void setCustst(java.lang.String custst) {
		this.custst = custst;
	}
	
	public java.lang.String getCustst() {
		return this.custst;
	}
	public void setPasswd(java.lang.String passwd) {
		this.passwd = passwd;
	}
	
	public java.lang.String getPasswd() {
		return this.passwd;
	}
	/*改为spring 声明式格式化
	public String getLogintimeString() {
		return com.htffund.etrade.sdk.util.DateConvertUtils.format(getLogintime(), FORMAT_LOGINTIME);
	}
	public void setLogintimeString(String value) {
		setLogintime(com.htffund.etrade.sdk.util.DateConvertUtils.parse(value, FORMAT_LOGINTIME,java.util.Date.class));
	}
	*/
	public void setLogintime(java.util.Date logintime) {
		this.logintime = logintime;
	}
	
	public java.util.Date getLogintime() {
		return this.logintime;
	}
	public void setLogincount(java.lang.Integer logincount) {
		this.logincount = logincount;
	}
	
	public java.lang.Integer getLogincount() {
		return this.logincount;
	}
	public void setPasswderr(Integer passwderr) {
		this.passwderr = passwderr;
	}
	
	public Integer getPasswderr() {
		return this.passwderr;
	}
	public void setOpendt(java.lang.String opendt) {
		this.opendt = opendt;
	}
	
	public java.lang.String getOpendt() {
		return this.opendt;
	}
	/*改为spring 声明式格式化
	public String getUpdatetimestampString() {
		return com.htffund.etrade.sdk.util.DateConvertUtils.format(getUpdatetimestamp(), FORMAT_UPDATETIMESTAMP);
	}
	public void setUpdatetimestampString(String value) {
		setUpdatetimestamp(com.htffund.etrade.sdk.util.DateConvertUtils.parse(value, FORMAT_UPDATETIMESTAMP,java.util.Date.class));
	}
	*/
	public void setUpdatetimestamp(java.util.Date updatetimestamp) {
		this.updatetimestamp = updatetimestamp;
	}
	
	public java.util.Date getUpdatetimestamp() {
		return this.updatetimestamp;
	}
	public void setCustid(java.math.BigDecimal custid) {
		this.custid = custid;
	}
	
	public java.math.BigDecimal getCustid() {
		return this.custid;
	}
	public void setTradepwd(java.lang.String tradepwd) {
		this.tradepwd = tradepwd;
	}
	
	public java.lang.String getTradepwd() {
		return this.tradepwd;
	}



public String toString() {
		return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
			.append("Custno",getCustno())
			.append("Invtp",getInvtp())
			.append("Invnm",getInvnm())
			.append("Idtp",getIdtp())
			.append("Idno",getIdno())
			.append("Mobileno",getMobileno())
			.append("Email",getEmail())
			.append("Custst",getCustst())
			.append("Passwd",getPasswd())
			.append("Logintime",getLogintime())
			.append("Logincount",getLogincount())
			.append("Passwderr",getPasswderr())
			.append("Opendt",getOpendt())
			.append("Updatetimestamp",getUpdatetimestamp())
			.append("Custid",getCustid())
			.append("Tradepwd",getTradepwd())
			.toString();
	}
	
	public int hashCode() {
		return new HashCodeBuilder()
			.append(getCustno())
			.toHashCode();
	}
	
	public boolean equals(Object obj) {
		if(obj instanceof Custinfo == false) return false;
		if(this == obj) return true;
		Custinfo other = (Custinfo)obj;
		return new EqualsBuilder()
			.append(getCustno(),other.getCustno())
			.isEquals();
	}
}