/*
 * Author: [Your Name]
 * Since :  2015-09-266
 * Copyright: www.99fund.com 
 */
package com.htffund.etrade.demo.web.controller;

import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.htffund.etrade.demo.manager.CustinfoManager;
import com.htffund.etrade.demo.model.Custinfo;
import com.htffund.etrade.demo.vo.CustinfoVO;
import com.htffund.etrade.sdk.base.json.JsonResult;
import com.htffund.etrade.sdk.base.paginator.domain.PageBounds;
import com.htffund.etrade.sdk.base.vo.PageVO;

/**
 * @author [Your Name]
 * @version 1.0
 * @since 1.0
 */
 

@Controller
@RequestMapping(value = "/Custinfo")
public class CustinfoController {
	/**logger*/
	static final Logger log = LogManager.getLogger(CustinfoController.class.getName());
	
	@Autowired
	private CustinfoManager custinfoManager;
	
	/**列出所有记录
	 * @param model 数据对象
	 * @return
	 */
	@RequestMapping(value = "listAll.htm")
	public String list(Model model){
		log.debug("execute  CustinfoController listAll");
		model.addAttribute("custinfoList",custinfoManager.listAll());
		return "custinfo/listall";
	}
	/**分页查询
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "list.htm")
	public String pageList(CustinfoVO custinfoVO,PageVO pageVO, Model model){
		log.debug("execute  CustinfoController list");
		PageBounds pageBounds=pageVO.toPageBounds();
		List<Custinfo> pageList=custinfoManager.pageList(custinfoVO,pageBounds);
		//分页查询结果列表		
		model.addAttribute("pageList",pageList);
		//回传查询参数
		model.addAttribute("params",custinfoVO);
		return "custinfo/list";
	}
	
	/**根据ID查询记录信息
	 * @param custno 客户编号 
	 * @param model 数据对象
	 * @return
	 */
	@RequestMapping(value = "show.htm")
	public String getCustinfo(@RequestParam("custno") String custno, Model model){
		log.debug("execute  CustinfoController getCustinfo");
		model.addAttribute("custinfo",custinfoManager.getCustinfo( custno  ));
		return "custinfo/show";
	}

	/**转到添加用户界面
	 * @return 
	 */
	@RequestMapping(value = "add.htm")
	public String addCustinfo(){
		log.debug("execute  CustinfoController add");
		return "custinfo/add";
	}
	
	/**添加用户
	 * @return json结果
	 */
	@RequestMapping(value = "save.htm")
	@ResponseBody
	public JsonResult saveCustinfo(Custinfo custinfo){
		log.debug("execute  CustinfoController save");
		//log.debug(custinfo.toString());
		try{
			custinfoManager.save(custinfo);
		}catch(Exception e){
			return new JsonResult(false,"后台错误:"+e.getMessage());
		}
		return new JsonResult(true,"return ok");
	}
	
	/**转到用户编辑页面
	  * @param custno 客户编号 
	 * @param model 数据对象
	 * @return
	 */
	@RequestMapping(value = "edit.htm")
	public String editCustinfo(@RequestParam("custno") String custno, Model model){
		log.debug("execute  CustinfoController edit");
		model.addAttribute("custinfo",custinfoManager.getCustinfo( custno  ));
		return "custinfo/edit";
	}
	
	/**更新用户信息
	 * @return json结果
	 */
	@RequestMapping(value = "update.htm")
	@ResponseBody
	public JsonResult updateCustinfo(Custinfo custinfo){
		log.debug("execute  CustinfoController update");
		try{
			custinfoManager.update(custinfo);
		}catch(Exception e){
			return new JsonResult(false,"后台错误:"+e.getMessage());
		}
		return new JsonResult(true,"return ok");
	}
	/**删除用户
	 * @param custinfoId 用户ID
	 * @return
	 */
	@RequestMapping(value = "delete.htm")
	@ResponseBody
	public JsonResult deleteCustinfo(Custinfo custinfo){
		log.debug("execute  CustinfoController delete");
		try{
			custinfoManager.delete(custinfo);
		}catch(Exception e){
			return new JsonResult(false,"后台错误:"+e.getMessage());
		}
		return new JsonResult(true,"return ok");
	}

	
	//以下为参考方法
	 /**根据客户ID查找
	 * @param custid 客户ID
	 * @return 结果对象
	 */
	@RequestMapping(value = "getByCustid.htm")
	public String getByCustid(java.math.BigDecimal custid, Model model){
		log.debug("execute  CustinfoController getByCustid");
		model.addAttribute("custinfo",custinfoManager.getByCustid(custid));
		return "custinfo/show";
	}
	 

}