/*
 * Author: [Your Name]
 * Since :  2015-09-266
 * Copyright: www.99fund.com 
 */
package com.htffund.etrade.demo.manager;

import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.htffund.etrade.demo.dao.CustinfoMapper;
import com.htffund.etrade.demo.manager.CustinfoManager;
import com.htffund.etrade.demo.model.Custinfo;
import com.htffund.etrade.demo.vo.CustinfoVO;
import com.htffund.etrade.sdk.base.paginator.domain.PageBounds;

/**
 * @author [Your Name]
 * @version 1.0
 * @since 1.0
 */
 
@Service("custinfoManager")
public class CustinfoManager {
	/**logger*/
	static final Logger log = LogManager.getLogger(CustinfoManager.class.getName());
	
	@Autowired
	private CustinfoMapper custinfoMapper;

  /**查询所有结果
	 * @return 结果列表
	 */
	public List<Custinfo> listAll(){
		return custinfoMapper.listAll();
	}
	
	/**根据ID查找
	 * @param custno 客户编号 
	 * @return 结果对象
	 */
	public Custinfo getCustinfo( java.lang.String custno  ){
		return custinfoMapper.getById( custno  );
	}

	/** 保存对象
	 * @param custinfo
	 */
	public void save(Custinfo custinfo) {
		custinfoMapper.save(custinfo);
		
	}

	/** 更新对象
	 * @param custinfo
	 * @return 更新记录数
	 */
	public int update(Custinfo custinfo) {
		return custinfoMapper.update(custinfo);
		
	}

	/** 删除对象
	 * @param custinfo
	 * @return 删除记录数
	 */
	public int delete(Custinfo custinfo) {
		return custinfoMapper.delete(custinfo);

	}

	/** 分页查询
	 * @param custinfoVO 查询参数
	 * @param pageBounds 分页参数
	 * @return 结果对象列表
	 */
	public List<Custinfo> pageList(CustinfoVO custinfoVO, PageBounds pageBounds) {
		List<Custinfo> list= custinfoMapper.pageList(custinfoVO,pageBounds);
		return  list;
		
	}
	
	/**根据客户ID查找
	 * @param custid 客户ID
	 * @return 结果对象
	 */
	public Custinfo getByCustid(java.math.BigDecimal custid){
		return custinfoMapper.getByCustid(custid);
	}
	
	
}
