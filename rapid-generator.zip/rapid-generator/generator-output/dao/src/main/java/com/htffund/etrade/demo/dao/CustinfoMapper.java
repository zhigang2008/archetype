/*
 * Author: [Your Name]
 * Since :  2015-09-266
 * Copyright: www.99fund.com 
 */
package com.htffund.etrade.demo.dao;

import java.util.List;
import com.htffund.etrade.demo.model.Custinfo;
import com.htffund.etrade.demo.vo.CustinfoVO;
import com.htffund.etrade.sdk.base.paginator.domain.PageBounds;

/**
 * @author [Your Name]
 * @version 1.0
 * @since 1.0
 */
 
public interface CustinfoMapper {
	
	/**查询所有结果
	 * @return 结果列表
	 */
	public List<Custinfo> listAll();
	
	/**根据ID查找
	 * @param custno 客户编号 
	 * @return 结果对象
	 */
	public Custinfo getById( java.lang.String custno  );
 
 /** 保存对象
	 * @param custinfo
	 */
	public void save(Custinfo custinfo);
	
	/** 更新对象
	 * @param custinfo
	 * @return 更新记录数
	 */
	public int update(Custinfo custinfo);
	
	/** 删除对象
	 * @param custinfo
	 * @return 删除记录数
	 */
	public int delete(Custinfo custinfo);
	
	 /** 分页查询
	 * @param custinfoVO 查询参数
	 * @param pageBounds 分页参数
	 * @return 结果对象列表
	 */
	public List<Custinfo> pageList(CustinfoVO custinfoVO, PageBounds pageBounds);
	
	 /**根据客户ID查找
	 * @param custid 客户ID
	 * @return 结果对象
	 */
	 public Custinfo getByCustid(java.math.BigDecimal custid);
	 

}