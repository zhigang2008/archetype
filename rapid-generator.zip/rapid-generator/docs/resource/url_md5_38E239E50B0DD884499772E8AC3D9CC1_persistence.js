<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3c.org/TR/1999/REC-html401-19991224/loose.dtd">

<html>
<head><meta content="text/html; charset=utf-8" http-equiv="Content-Type" /><script type="text/javascript">
   var _U = "undefined";
   var g_HttpRelativeWebRoot = "/ocom/";
   var SSContributor = false;
   var SSForceContributor = false;
   var SSHideContributorUI = false;
   var ssUrlPrefix = "/technetwork/";
   var ssUrlType = "2";
   
   var g_navNode_Path = new Array();
       g_navNode_Path[0] = 'otnen';
       g_navNode_Path[1] = 'otnen_java';
       g_navNode_Path[2] = 'otnen_javaee';
       g_navNode_Path[3] = 'otnen_javaee_tech';
   var g_ssSourceNodeId = "otnen_javaee_tech";
   var g_ssSourceSiteId = "otnen";
   var g_strLanguageId = "en";
</script>
<script id="SSNavigationFunctionsScript" type="text/javascript" src="/ocom/websites/otnen/sitenavigationfunctions.js"></script>
<script id="SSNavigationScript" type="text/javascript" src="/ocom/websites/otnen/sitenavigation.js"></script>

	<script type="text/javascript" src="/ocom/resources/wcm/sitestudio/wcm.toggle.js"></script>
	<script type="text/javascript" src="/ocom/resources/sitestudio/ssajax/ssajax.js"></script>


  <script id="ssInfo" type="text/xml" warning="DO NOT MODIFY!">
  <ssinfo >
    <fragmentinstance  id="fragment14" fragmentid="Universal_Localization_Fragment" library="server:UNIVERSAL_LOCALIZATION_FRAG">
    </fragmentinstance>
    <fragmentinstance  id="fragment16" fragmentid="Universal_Localization_Fragment" library="server:UNIVERSAL_LOCALIZATION_FRAG">
    </fragmentinstance>
    <fragmentinstance  id="fragment17" fragmentid="Universal_Localization_Fragment" library="server:UNIVERSAL_LOCALIZATION_FRAG">
    </fragmentinstance>
    <fragmentinstance  id="fragment18" fragmentid="universal-search-fragment" library="server:UNIVERSAL-SEARCH-FRAGMET-LIB">
      
    </fragmentinstance>
    <fragmentinstance  id="fragment22" fragmentid="Universal_Localization_Fragment" library="server:UNIVERSAL_LOCALIZATION_FRAG">
    </fragmentinstance>
    <fragmentinstance  id="fragment23" fragmentid="ocom-commonassets" library="server:OCOM-FRAGMENT-LIBRARAY">
      
    </fragmentinstance>
    <fragmentinstance  id="fragment24" fragmentid="ExternalNavigationHorizontal" library="server:EXTERNALNAVHORIZONTALLIB">
    </fragmentinstance>
    <fragmentinstance  id="fragment25" fragmentid="ExternalNavVertical" library="server:EXTERNAL_NAV_VERTICAL">
    </fragmentinstance>
    <fragmentinstance  id="fragment27" fragmentid="Universal_Localization_Fragment" library="server:UNIVERSAL_LOCALIZATION_FRAG">
    </fragmentinstance>
    <fragmentinstance  id="fragment28" fragmentid="Universal_Localization_Fragment" library="server:UNIVERSAL_LOCALIZATION_FRAG">
    </fragmentinstance>
    <fragmentinstance  id="fragment29" fragmentid="ExternalBreadCrumb" library="server:EXTERNAL_BREADCRUMB">
    </fragmentinstance>
    <fragmentinstance  id="fragment32" fragmentid="universal-metatag" library="server:UNIVERSAL-FRAGMENTS">
    </fragmentinstance>
    <fragmentinstance  id="fragment33" fragmentid="ExternalNavTabsTop" library="server:EXTERNAL_NAV_TABS_TOP">
    </fragmentinstance>
    <fragmentinstance  id="fragment35" fragmentid="universal-webcache-integration" library="server:UNIVERSAL-WEBCACHE-INTEGRATION">
      
    </fragmentinstance>
    <fragmentinstance  id="fragment36" fragmentid="ExternalSiteCatalystFragment" library="server:EXTERNALSCFRAGMENTLIB">
      
    </fragmentinstance>
    <fragmentinstance  id="fragment37" fragmentid="Universal_Localization_Fragment" library="server:UNIVERSAL_LOCALIZATION_FRAG">
    </fragmentinstance>
  </ssinfo>
  </script>

 
  

  <script language="JavaScript" type="text/javascript" src="/ocom/groups/systemobject/@mktg_admin/documents/webcontent/oraclelib.js">
  </script>
  <style type="text/css">
    HTML,BODY,TD,H1,H2,H3,H4,OL,UL,DL,LI,DT,DD {font-family:arial,helvetica,sans-serif;}
    HTML,BODY,TD,CODE,KBD,TT,OL,UL,DL,LI,DT,DD {font-size:12px;}
    a:link {color:#000;text-decoration:none;}
    a:visited {color:#000;text-decoration:none;}
    a:hover {color:#FF0000;text-decoration:underline;}

    #Wrapper_FixedWidth {text-align: left; margin: 0px auto; padding: 0px; border:0; width: 1000px;}
    #Wrapper_FixedWidth_Header {margin: 0 0 15px 0; width:100%; display:block; }
    #Wrapper_FixedWidth_Leftnav {float: left; width: 181px;}
    #Wrapper_FixedWidth_Rightnav {float: right;  width: 185px; }
    #Wrapper_FixedWidth_Centercontent {float: left; width: 810px;}
    #Wrapper_FixedWidth_Maincontent {float: left; width: 595px;}
    #Wrapper_FixedWidth_Footer{ clear: both; }
    .header{display:block; width:100%; padding:2px 0px 5px 0px; margin:0px 0px 10px 0px;}
    .logo{width:140px; float:left; padding:12px 0px 0px 12px;}
    .welcomeMsg{text-align:right; font-size:10px; padding:5px 12px 0px 0px; float:right;}
    .secureSearch{text-align:right; padding:10px 0px 0px 0px; margin-top:20px;}
    .greybarhomebot{background: #DCDCDC;height: 7px; margin-top: 7px; float:left; width:100%; margin-top:20px;}
    .footerLinks {font-size:10px;}
    .sngPsta {font-size:11px;line-height:13px;color:#000;text-align:left;}
    a.sngPsta:link {color:#000;text-decoration:none;display:block;padding:3px 10px;}
    a.sngPsta:visited {color:#000;text-decoration:none;display:block;padding:3px 10px;}
    a.sngPsta:hover {color:#fff;text-decoration:none;display:block;background-color:#9a9a9a;padding:3px 10px;}
    /* For Mosaic */
    ul#navigation li.top-level p a.noimg {background:none;}
    /* For Mosaic */
    #centerSectBlankPS {display: block;min-width: 570px;}
    .lock {position:absolute; top:1px;*top:1px; left:152px; margin:0px; padding:0px;}
  </style>
  <link rel="stylesheet" type="text/css" href="/ocom/groups/systemobject/@mktg_admin/documents/webcontent/master.css" media="screen" />
  <link rel="stylesheet" type="text/css" href="/ocom/groups/systemobject/@mktg_admin/documents/systemobject/otn.css" media="screen" />
  <link rel="stylesheet" type="text/css" href="/ocom/groups/systemobject/@mktg_admin/documents/systemobject/ocom-decouple.css" media="screen" /><!--<link media="screen" href="/ocom/groups/systemobject/@mktg_admin/documents/systemobject/sdn.css" type="text/css" rel="stylesheet" /> -->
  <meta name="GENERATOR" content="MSHTML 8.00.6001.18928" />
<!--SS_BEGIN_SNIPPET(fragment32,code)-->
				
			<!--SS_END_SNIPPET(fragment32,code)-->

  <style type="text/css">
    <!-- Add logo class to styles.css file -->
    .logo{FLOAT: left; WIDTH: 151px;  PADDING-TOP: 4px}
    #centerSectBlankPS {display: block;min-width: 570px;}
    .sunquicklinks_wrapper{DISPLAY: block; FLOAT: right; WIDTH: 200px; TEXT-ALIGN: right;}
    .welcomesignin_wrapper{FLOAT: left; WIDTH: 634px; *width:621px; TEXT-ALIGN: right;VERTICAL-ALIGN: bottom; PADDING-TOP: 12px}
    .logo_wrapper{DISPLAY: block; MARGIN-BOTTOM: 6px; float:left; WIDTH: 974px; HEIGHT: 40px;}
  </style><!--Mosaic Header --><!--[if IE]>
  <STYLE>
    .logo_align{margin-bottom: 4px; margin-left:0px;}
    .search_position{margin:7px 3px 14px 16px;}
    #panelDiv_search .contentBg{padding:15px 5px 5px 5px; } 
    ul#navigation div.submenu {border-bottom:1px solid #b7b7b7;}
    ul#navigation div.submenu .bottomleft{background:none; width:15px; height:30px; float:left;  margin-left:-16px; margin-bottom:-42px; }
    ul#navigation div.submenu .bottomcenter{background:none; height:30px;  margin-left:15px; margin-right:15px; float:left; width:360px;} 
    ul#navigation div.submenu .bottomright{background:none; width:15px; height:30px; float:left; margin-left:360px; }
    ul#navigation div.submenu .partner_bottomleft{ background:none; width:15px; height:30px;  float:left; margin-left:-16px; margin-bottom:-42px; clear:left; margin-top:15px;}
    ul#navigation div.submenu .partner_bottomcenter{  background:none; width:362px; height:30px; margin-left:15px;  float:center;}
    ul#navigation div.submenu .partner_bottomright{  background:none; width:15px; height:30px; float:right; margin-right:-15px;}
    </STYLE>
  <![endif]-->
<!--SS_BEGIN_SNIPPET(fragment29,1)--><!--SS_END_SNIPPET(fragment29,1)-->

  <script type="text/javascript">
    $(document).observe('dom:loaded', function() {
        $$('ul#navigation li').each(function(li){
            li.observe('mouseover', function(){
                li.addClassName('hover');
            });
            li.observe('mouseout', function(){
                li.removeClassName('hover');
            });
        });
    });
  </script>
<!--SS_BEGIN_SNIPPET(fragment32,head_tags)-->	
<title>Java EE 6 Technologies</title>
<meta name="Title" content="Java EE 6 Technologies">
<meta name="Description" content="Learn more about the technologies that comprise the Java EE 6 platform">
<meta name="Keywords" content="">
<meta name="robots" content="INDEX, FOLLOW">
<meta name="country" content="USA">
<meta name="Language" content="en">
<meta name="Updated Date" content="7/26/10 6:20 PM">




			<!--SS_END_SNIPPET(fragment32,head_tags)-->

<!--SS_BEGIN_SNIPPET(fragment33,1)-->				<link rel="stylesheet" type="text/css" href="/ocom/fragments/externalnavtabstop/receiver.css" type="text/css" media="screen" />


<script type="text/javascript" charset="utf-8" src="/ocom/fragments/externalnavtabstop/receiver.js"></script>
			<!--SS_END_SNIPPET(fragment33,1)-->

<!--SS_BEGIN_SNIPPET(fragment35,code)-->
			<!--SS_END_SNIPPET(fragment35,code)-->

</head>

<body>
  <div id="Wrapper_FixedWidth">
    <div id="Wrapper_FixedWidth_Header">
      <div style="HEIGHT: 140px" class="header">
        <div class="sunquicklinks_wrapper">
          
<!--SS_BEGIN_SNIPPET(fragment27,ocom translation)-->				<!--** retrieve cache lifespan parameter: **-->

	
	<!--**override root for testing purposes:**-->
	<!--** Header Logo ** -->
	<!--** Header Search ** -->
	<!--** Welcome SignIn ** -->
	 
	
	<!--** Footer ** -->
	
	 
		
<!--** Header Logo ** -->
	 
	
		

	<!-- MOSAIC -->
<!-- Communities-->

<!-- User Category -->
 
<!-- User Intrest -->
<!-- Navigation starts here -->
			
					
						
																	
						
		                
				
				
				
			
		
						
			
			
				
			
		
			
				
				
						
				

				

				

				


				
		
						
						
				
				
			
			
			
			
				 
<!-- User Community SC code -->

<!-- User Category SC code -->

 
<!-- User Interest SC code -->


<script type="text/javascript">
var OracleandSun = new Array();
OracleandSun[0] = 'http://www.oracleimg.com/ocom/groups/systemobject/@mktg_admin/documents/digitalasset/oracle-sun-btn.png';
OracleandSun[1] = 'http://www.oracleimg.com/ocom/groups/systemobject/@mktg_admin/documents/digitalasset/oracle-sun-btn-on.png';
oracleAndsun('otn','en');
</script>
<div style='float:right'><a href='http://www.oracle.com/sun/index.html' onclick="navTrack('otn','en','header','oracle and sun');"><img src='http://www.oracleimg.com/ocom/groups/systemobject/@mktg_admin/documents/digitalasset/oracle-sun-btn.png' id='oracleandsun' alt='Sun Quick Links' width='107' height='21' border='0' onMouseOver="mvqMOv('panelDiva','oracleandsun');this.src=OracleandSun[1];" onMouseOut="mvqMOu('panelDiva');this.src=OracleandSun[0];"></a></div>

			<!--SS_END_SNIPPET(fragment27,ocom translation)-->

        </div>

        <div class="logo_wrapper">
          <div style="PADDING-TOP: 4px" class="logo">
            
<!--SS_BEGIN_SNIPPET(fragment37,ocom translation)-->				<!--** retrieve cache lifespan parameter: **-->

	
	<!--**override root for testing purposes:**-->
	<!--** Header Logo ** -->
	<!--** Header Search ** -->
	<!--** Welcome SignIn ** -->
	 
	
	<!--** Footer ** -->
	
	 
		
<!--** Header Logo ** -->
	 
	
		

	<!-- MOSAIC -->
<!-- Communities-->

<!-- User Category -->
 
<!-- User Intrest -->
<!-- Navigation starts here -->
			
					
						
																	
						
		                
				
				
				
			
		
						
			
			
				
			
		
			
				
				
						
				

				

				

				


				
		
						
						
				
				
			
			
			
			
				 
<!-- User Community SC code -->

<!-- User Category SC code -->

 
<!-- User Interest SC code -->

<!-- Date: 7 Sep 2010 -->
<!-- Author: Girish Gowdar, web Technology -->
<!-- Comment : Logo img url and link customized. Variable declared in each Country translation file if need to customize. -->
<a href='http://www.oracle.com/' onclick="navTrack('otn','en','header','logo');"><img src='http://www.oracleimg.com/admin/images/ocom/hp/oralogo_small.gif' border='0' /></a>

			<!--SS_END_SNIPPET(fragment37,ocom translation)-->

          </div>

          <div class="welcomesignin_wrapper">
            
<!--SS_BEGIN_SNIPPET(fragment14,ocom translation)-->				<!--** retrieve cache lifespan parameter: **-->

	
	<!--**override root for testing purposes:**-->
	<!--** Header Logo ** -->
	<!--** Header Search ** -->
	<!--** Welcome SignIn ** -->
	 
	
	<!--** Footer ** -->
	
	 
		
<!--** Header Logo ** -->
	 
	
		

	<!-- MOSAIC -->
<!-- Communities-->

<!-- User Category -->
 
<!-- User Intrest -->
<!-- Navigation starts here -->
			
					
						
																	
						
		                
				
				
				
			
		
						
			
			
				
			
		
			
				
				
						
				

				

				

				


				
		
						
						
				
				
			
			
			
			
				 
<!-- User Community SC code -->

<!-- User Category SC code -->

 
<!-- User Interest SC code -->

<span class="profile">
	<script type="text/javascript">
		if ( USER.guid )
		{
			document.write('Welcome ' + USER.firstname + ' ( <a class=profile href=https://myprofile.oracle.com/EndUser/faces/profile/sso/updateUser.jspx?nextURL=' + location.href +'>' + 'Account' + '</a> | <a class=profile href=http://www.oracle.com/corporate/contact/accounthelp.html>' + 'Help' + '</a> | <a class=profile href=javascript:sso_sign_out();>' + 'Sign Out' + '</a> )');
		}
		else
		{
			document.write('<span class=profile>( ' + ' <a href=http://login.oracle.com/redirect/signon?nexturl=' + location.href + '>Sign In/Register for Account</a> ' + ' <span style=color: rgb(0, 0, 0)>|</span> ' + '<a href=http://www.oracle.com/corporate/contact/accounthelp.html>Help</a>' + ' )</span>' );
		}
	</script>
	<a class="legalese" onmouseover="mvqMOv('panelDivOTN','img1');" onmouseout="mvqMOu('panelDivOTN');" href="#">United States<img style="MARGIN-LEFT: 4px;" id="img1" border="0" alt="Change Country, Oracle Worldwide Web Sites"  src="http://www.oracleimg.com/ocom/groups/public/documents/digitalasset/dropdown-arrow-new.gif" /></a>
     <script language="JavaScript" type="text/javascript">OTNWorldwideCountries();</script>
</span>

			<!--SS_END_SNIPPET(fragment14,ocom translation)-->

<!--SS_BEGIN_SNIPPET(fragment28,ocom translation)-->				<!--** retrieve cache lifespan parameter: **-->

	
	<!--**override root for testing purposes:**-->
	<!--** Header Logo ** -->
	<!--** Header Search ** -->
	<!--** Welcome SignIn ** -->
	 
	
	<!--** Footer ** -->
	
	 
		
<!--** Header Logo ** -->
	 
	
		

	<!-- MOSAIC -->
<!-- Communities-->

<!-- User Category -->
 
<!-- User Intrest -->
<!-- Navigation starts here -->
			
					
						
																	
						
		                
				
				
				
			
		
						
			
			
				
			
		
			
				
				
						
				

				

				

				


				
		
						
						
				
				
			
			
			
			
				 
<!-- User Community SC code -->

<!-- User Category SC code -->

 
<!-- User Interest SC code -->

<a href='/us/community/index.html' class='legalese' onMouseOver="mvqMOv('panelDiv_comm','img2');" onMouseOut="mvqMOu('panelDiv_comm');" onclick="navTrack('otn','en','header','communities');">Communities<img src='http://www.oracleimg.com/ocom/groups/public/documents/digitalasset/dropdown-arrow-new.gif' style='margin-left: 4px;' border='0' id='img2'></a>
<div id='panelDiv_comm' style='position:absolute;right:50%; margin-right:-383px; visibility:hidden; z-index:20000; WIDTH: 180px; border:1px solid #9A9A9A; padding:12px; BACKGROUND-COLOR: #ffffff' onmouseover="mvqMOv('panelDiv_comm','img2');" onmouseout="mvqMOu('panelDiv_comm');">
<table width='100%'><tr valign='top' align='left'><td width='30%' class='sngPst'>
	<div><b>Social Applications</b></a></div>
			<div ><a href='https://mix.oracle.com/' class='sngPst' onclick="navTrack('otn','en','header','oraclemix');">Oracle Mix</a></div>
			<div ><a href='/blogs/index.html' class='sngPst' onclick="navTrack('otn','en','header','oracleblogs');">Oracle Blogs</a></div>
			<div ><a href='http://wiki.oracle.com/' class='sngPst' onclick="navTrack('otn','en','header','oraclewiki');">Oracle Wiki</a></div>
			<div ><a href='http://www.facebook.com/Oracle' class='sngPst' onclick="navTrack('otn','en','header','oracleonfacebook');">Oracle on Facebook</a></div>
			<div ><a href='http://twitter.com/oracle' class='sngPst' onclick="navTrack('otn','en','header','oracleontwitter');">Oracle on Twitter</a></div>
			<div style='padding-bottom:10px;'><!--spacer--></div>
			<div ><b>Networks</b></a></div>
			<div ><a href='/technetwork/community/oracle-ace/index.html' class='sngPst' onclick="navTrack('otn','en','header','oracleaces');">Oracle ACEs</a></div>
			<div ><a href='/partners/index.htm' class='sngPst' onclick="navTrack('otn','en','header','oraclepartnernetwork');">Oracle PartnerNetwork</a></div>
			<div ><a href='/technetwork/index.html' class='sngPst' onclick="navTrack('otn','en','header','oracletechnologynetwork');">Oracle Technology Network</a></div>
			<div style='padding-bottom:10px;'><!--spacer--></div>
			<div ><b>Knowledge Base</b></a></div>
			<div ><a href='/technology/community/user_groups/index.html' class='sngPst' onclick="navTrack('otn','en','header','oracleusergroups');">Oracle User Groups</a></div>
			<div ><a href='http://forums.oracle.com/forums/index.jspa?cat=1' class='sngPst' onclick="navTrack('otn','en','header','oraclediscussionforums');">Oracle Discussion Forums</a></div>
			<div style='padding-bottom:10px;'><!--spacer--></div>
			<div ><b>Support</b></a></div>
			<div ><a href='https://communities.oracle.com/portal/server.pt/community/support/219' class='sngPst' onclick="navTrack('otn','en','header','myoraclesupportcommunity');">My Oracle Support Community</a></div>
			<div style='padding-bottom:10px;'><!--spacer--></div>
			<div ><b></b></a></div>
<tr><td></td></tr>
</table></div>

			<!--SS_END_SNIPPET(fragment28,ocom translation)-->

<!--SS_BEGIN_SNIPPET(fragment16,ocom translation)-->				<!--** retrieve cache lifespan parameter: **-->

	
	<!--**override root for testing purposes:**-->
	<!--** Header Logo ** -->
	<!--** Header Search ** -->
	<!--** Welcome SignIn ** -->
	 
	
	<!--** Footer ** -->
	
	 
		
<!--** Header Logo ** -->
	 
	
		

	<!-- MOSAIC -->
<!-- Communities-->

<!-- User Category -->
 
<!-- User Intrest -->
<!-- Navigation starts here -->
			
					
						
																	
						
		                
				
				
				
			
		
						
			
			
				
			
		
			
				
				
						
				

				

				

				


				
		
						
						
				
				
			
			
			
			
				 
<!-- User Community SC code -->

<!-- User Category SC code -->

 
<!-- User Interest SC code -->

<a href='#' class='legalese' onMouseOver="mvqMOv('panelDiv_iam','img3');" onMouseOut="mvqMOu('panelDiv_iam');">I am a...<img src='http://www.oracleimg.com/ocom/groups/public/documents/digitalasset/dropdown-arrow-new.gif' style='margin-left: 4px;' border='0' id='img3'></a>
<div id='panelDiv_iam' style='position:absolute;right:50%; margin-right:-383px; visibility:hidden; z-index:20000; WIDTH: 180px; border:1px solid #9A9A9A; padding:12px;  BACKGROUND-COLOR: #ffffff' onmouseover="mvqMOv('panelDiv_iam','img3');" onmouseout="mvqMOu('panelDiv_iam');">
<table width='100%'>
<tr valign=top align=left><td width=30% class='sngPst'>
			<div ><a href='http://www.oracle.com/technetwork/java' class='sngPst' onclick="navTrack('otn','en','header','javadeveloper');">Java Developer</a></div>
			<div ><a href='/technetwork/dbadev' class='sngPst' onclick="navTrack('otn','en','header','databaseadminsanddevelopers');">Database Admins and Developers</a></div>
			<div ><a href='/technetwork/systems' class='sngPst' onclick="navTrack('otn','en','header','systemadminsanddevelopers');">System Admins and Developers</a></div>
			<div ><a href='/technetwork/architect' class='sngPst' onclick="navTrack('otn','en','header','architect');">Architect</a></div>
			<div style='padding-bottom:10px;'><!--spacer--></div>
			<div ><b>C-Level Executives</b></a></div>
			<div ><a href='http://oraclecfo.com' class='sngPst' onclick="navTrack('otn','en','header','chieffinancialofficer(cfo)');">Chief Financial Officer (CFO)</a></div>
			<div ><a href='http://oraclecio.com' class='sngPst' onclick="navTrack('otn','en','header','chiefinformationofficer(cio)');">Chief Information Officer (CIO)</a></div>
			<div style='padding-bottom:10px;'><!--spacer--></div>
			<div ><b>Other Roles</b></a></div>
			<div ><a href='/corporate/analyst/index.html' class='sngPst' onclick="navTrack('otn','en','header','analyst');">Analyst</a></div>
			<div ><a href='/corporate/investor_relations/index.html' class='sngPst' onclick="navTrack('otn','en','header','investor');">Investor</a></div>
			<div ><a href='http://www.oracle.com/corporate/employment/index.html' class='sngPst' onclick="navTrack('otn','en','header','jobseeker');">Job Seeker</a></div>
			<div ><a href='/partners/index.htm' class='sngPst' onclick="navTrack('otn','en','header','partner');">Partner</a></div>
			<div ><a href='/us/products/applications/peoplesoft-enterprise/index.html' class='sngPst' onclick="navTrack('otn','en','header','peoplesoftcustomer');">PeopleSoft Customer</a></div>
			<div ><a href='/siebel/index.html' class='sngPst' onclick="navTrack('otn','en','header','siebelcustomer');">Siebel Customer</a></div>
			<div ><a href='/us/sun/index.html' class='sngPst' onclick="navTrack('otn','en','header','suncustomer');">Sun Customer</a></div>
			<div ><a href='https://academy.oracle.com/' class='sngPst' onclick="navTrack('otn','en','header','student');">Student</a></div>
			<div ><a href='/us/solutions/midsize/index.html' class='sngPst' onclick="navTrack('otn','en','header','midsizecompany');">Midsize Company</a></div>
			<div style='padding-bottom:10px;'><!--spacer--></div>
			<div ><b></b></a></div>
<tr><td></td></tr>
</table>
</div>

			<!--SS_END_SNIPPET(fragment16,ocom translation)-->

<!--SS_BEGIN_SNIPPET(fragment17,ocom translation)-->				<!--** retrieve cache lifespan parameter: **-->

	
	<!--**override root for testing purposes:**-->
	<!--** Header Logo ** -->
	<!--** Header Search ** -->
	<!--** Welcome SignIn ** -->
	 
	
	<!--** Footer ** -->
	
	 
		
<!--** Header Logo ** -->
	 
	
		

	<!-- MOSAIC -->
<!-- Communities-->

<!-- User Category -->
 
<!-- User Intrest -->
<!-- Navigation starts here -->
			
					
						
																	
						
		                
				
				
				
			
		
						
			
			
				
			
		
			
				
				
						
				

				

				

				


				
		
						
						
				
				
			
			
			
			
				 
<!-- User Community SC code -->

<!-- User Category SC code -->

 
<!-- User Interest SC code -->

<a href='#' class='legalese' onMouseOver="mvqMOv('panelDiv_iwanto','img4');" onMouseOut="mvqMOu('panelDiv_iwanto');">I want to...<img src='http://www.oracleimg.com/ocom/groups/public/documents/digitalasset/dropdown-arrow-new.gif' style='margin-left: 4px;' border='0' id='img4'></a>
<div id='panelDiv_iwanto' style='position:absolute;right:50%; margin-right:-383px; visibility:hidden; z-index:20000; WIDTH: 180px; border:1px solid #9A9A9A; padding:12px; BACKGROUND-COLOR: #ffffff' onmouseover="mvqMOv('panelDiv_iwanto','img4');" onmouseout="mvqMOu('panelDiv_iwanto');">
<table width=100%>
<tr valign=top align=left><td width=30% class='sngPst'>
	<div><b>Support</b></a></div>
			<div ><a href='https://support.oracle.com/CSP/ui/flash.html#tab=SRHome(page=SRHome&id=g1txr1mm())' class='sngPst' onclick="navTrack('otn','en','header','createorupdateservicerequest');">Create or Update Service Request</a></div>
			<div ><a href='https://support.oracle.com/CSP/ui/flash.html#tab=KBHome(page=KBHome&id=g1txk01p())' class='sngPst' onclick="navTrack('otn','en','header','searchsupportknowledgedatabase');">Search Support Knowledge Database</a></div>
			<div ><a href='https://support.oracle.com/CSP/ui/flash.html#tab=PatchHomePage%28page=PatchHomePage&id=g1ws8maj%28%29%29' class='sngPst' onclick="navTrack('otn','en','header','downloadpatches');">Download Patches</a></div>
			<div style='padding-bottom:10px;'><!--spacer--></div>
			<div ><b>Education</b></a></div>
			<div ><a href='http://education.oracle.com/pls/web_prod-plq-dad/db_pages.getpage?page_id=3' class='sngPst' onclick="navTrack('otn','en','header','findoracleuniversitytraining');">Find Oracle University Training</a></div>
			<div ><a href='http://education.oracle.com/pls/web_prod-plq-dad/db_pages.getpage?page_id=141' class='sngPst' onclick="navTrack('otn','en','header','chooseanoraclecertificationpath');">Choose an Oracle Certification Path</a></div>
			<div style='padding-bottom:10px;'><!--spacer--></div>
			<div ><b>Partner</b></a></div>
			<div ><a href='http://solutions.oracle.com/' class='sngPst' onclick="navTrack('otn','en','header','findapartnersolution');">Find a Partner Solution</a></div>
			<div ><a href='/partners/secure/development/order-technology-software/' class='sngPst' onclick="navTrack('otn','en','header','accesssoftwareandtechnicalsupport');">Access Software and Technical Support</a></div>
			<div ><a href='http://opnevents.oracle.com/' class='sngPst' onclick="navTrack('otn','en','header','attendapartner-onlyevent');">Attend a Partner-Only Event</a></div>
			<div ><a href='/partners/en/most-popular-resources/028916.htm' class='sngPst' onclick="navTrack('otn','en','header','attendtraining');">Attend Training</a></div>
			<div ><a href='/partners/secure/marketing/download-logos/' class='sngPst' onclick="navTrack('otn','en','header','downloadlogos');">Download Logos</a></div>
			<div ><a href='http://solutions.oracle.com/portal/page/portal/OPN/sol_cat_wrapper/' class='sngPst' onclick="navTrack('otn','en','header','managesolutionscatalog');">Manage Solutions Catalog</a></div>
			<div style='padding-bottom:10px;'><!--spacer--></div>
			<div ><b>Other Tasks</b></a></div>
			<div ><a href='https://shop.oracle.com' class='sngPst' onclick="navTrack('otn','en','header','purchaseoracleproductsonline');">Purchase Oracle Products Online</a></div>
			<div ><a href='/technetwork/indexes/documentation/index.html' class='sngPst' onclick="navTrack('otn','en','header','browseoracledocumentation');">Browse Oracle Documentation</a></div>
			<div ><a href='http://www.oracle.com/pls/db92/db92.federated_search' class='sngPst' onclick="navTrack('otn','en','header','searchoracledocumentation');">Search Oracle Documentation</a></div>
			<div ><a href='/corporate/investor_relations/index.html' class='sngPst' onclick="navTrack('otn','en','header','checkoracleearnings');">Check Oracle Earnings</a></div>
			<div ><a href='/corporate/pricing/pricelists.html' class='sngPst' onclick="navTrack('otn','en','header','checkoraclepricelists');">Check Oracle Price Lists</a></div>
			<div ><a href='/technetwork/indexes/downloads/index.html' class='sngPst' onclick="navTrack('otn','en','header','downloadoraclesoftware');">Download Oracle Software</a></div>
			<div ><a href='http://apex.oracle.com/pls/otn/f?p=19297:3:2579654746979599' class='sngPst' onclick="navTrack('otn','en','header','findanoracleace');">Find an Oracle ACE</a></div>
			<div ><a href='http://www.oracle.com/us/solutions/performance-scalability/index.html' class='sngPst' onclick="navTrack('otn','en','header','vieworaclebenchmarks');">View Oracle Benchmarks</a></div>
			<div style='padding-bottom:10px;'><!--spacer--></div>
			<div ><b></b></a></div>
</td></tr>
<tr><td></td></tr>
</table>
</div>

			<!--SS_END_SNIPPET(fragment17,ocom translation)-->
<!--WORLDWIDE pop up menu-->
            <script language="JavaScript" type="text/javascript">
                        worldwideCountries();
            </script> <!--WORLDWIDE popup menu ends here -->
          </div>
<!--SS_BEGIN_SNIPPET(fragment18,1)-->				<div style="WIDTH: 173px; FLOAT: left; clear:right;">
<!--search text box -->

<div class="search_position" id="img5">
<form name="searchForm" onSubmit="javascript: return isNotNull(this.q.value)" method="get" action="http://search.oracle.com/search/search">
         <input name="start" value="1" type="hidden">
	 <input type="hidden" value="all" name="search_p_main_operator">
    <div id="serch_txtbox">
      <div class="search_text">
        <a onmouseout="mvqMOu('panelDiv_search')" onclick="mvqMOv('panelDiv_search','img5');" href="#"><img  src="/ocom/groups/systemobject/@mktg_admin/documents/digitalasset/search-filter-btn.png" /></a>
      </div>

      <div class="textbg">
        <input id="txtSearch" class="textcnt" name="q" onClick="javascript:if(!isUserInput) {document.searchForm.q.value='';}" onKeyDown="javascript:isUserInput=true;" value="Secure Search"/>
      </div>

      <div class="search_button">
        <a onClick="javascript: return isNotNull(document.searchForm.q.value)" href="javascript:document.searchForm.submit()"><img src="/ocom/groups/systemobject/@mktg_admin/documents/digitalasset/search-icon.gif" /></a>
      </div>
    </div><!--start sugession -->

     <div id="panelDiv_search" onMouseOver="mvqMOv('panelDiv_search','img5');" onMouseOut="mvqMOu('panelDiv_search')";>
     <div class="TopleftCurv"></div>
        <div class="centerTop"></div>
        	<div class="ToprightCurv"></div>
        		<div class="contentBg">&nbsp;<strong>Filters:</strong>
        		<div style="padding-bottom:5px; *padding-bottom:1px;"></div>
        		<ul>
                <li><input value="All" type="radio" name="group" />&nbsp;&nbsp;All</li>
        		<li><input value="Blogs" type="radio" name="group" />&nbsp;&nbsp;Blogs</li>
        		<li><input value="Corporate Site" type="radio" name="group"  />&nbsp;&nbsp;Corporate Site</li>
        		<li><input value="CRM On Demand" type="radio" name="group" />&nbsp;&nbsp;CRM On Demand</li>         		
        		<li><input value="Discussion Forums" type="radio" name="group" />&nbsp;&nbsp;Discussion Forums</li>
        		<li><input value="Documentation" type="radio" name="group" />&nbsp;&nbsp;Documentation</li>
        		<li><input value="Education" type="radio" name="group" />&nbsp;&nbsp;Education</li>
        		<li><input value="Java.com" type="radio" name="group" />&nbsp;&nbsp;Java.com</li>
        		<li><input value="JavaOne and Oracle Develop" type="radio" name="group" />&nbsp;&nbsp;JavaOne and Oracle Develop</li> 
			<li><input value="Oracle OpenWorld" type="radio" name="group" />&nbsp;&nbsp;Oracle OpenWorld</li>
        		<li><input value="PartnerNetwork" type="radio" name="group" />&nbsp;&nbsp;PartnerNetwork</li>
        		<li><input value="Technology Network" type="radio" name="group" checked="checked"/>&nbsp;&nbsp;Technology Network</li>
        		<li><input value="Video and Multimedia" type="radio" name="group" />&nbsp;&nbsp;Video and Multimedia</li>
        		</ul>
    		 </div>
        	<div class="BottomleftCurv"></div>
        <div class="centerBottom"></div>
      <div class="BottomrightCurv"></div>
     </div>
  </form>
</div>

<div id="errtxtSearch"></div><!--End Sugession -->
</div>
			<!--SS_END_SNIPPET(fragment18,1)-->

        </div>
<!--SS_BEGIN_SNIPPET(fragment24,1)-->
	
	<!--**override root for testing purposes:**-->
	<!--** Header Logo ** -->
	<!--** Header Search ** -->
	<!--** Welcome SignIn ** -->
	 
	
	<!--** Footer ** -->
	
	 
		
<!--** Header Logo ** -->
	 
	
		

	<!-- MOSAIC -->
<!-- Communities-->

<!-- User Category -->
 
<!-- User Intrest -->
<!-- Navigation starts here -->
			
					
						
																	
						
		                
				
				
				
			
		
						
			
			
				
			
		
			
				
				
						
				

				

				

				


				
		
						
						
				
				
			
			
			
			
				 
<!-- User Community SC code -->

<!-- User Category SC code -->

 
<!-- User Interest SC code -->


				
				
			
			
			
			
			
			

			
			

			
			
			

			
			
			
			
			
			
			
			

			
			
					
				
      				

	    	
	    	

			
		
	    	

	    		

	    			

                    	

	    	

	    	

	    	

    	    	

	    	

	    	
	
	
	    	
	    	
	    	

	    			
	    			
	    			

	    

	    

	    

	   

	    

	      		

	    

	     	

         

	    

	    

	    

	   

	 
	    

			

	<ul id="navigation" class="menu">

		<li class="top-level" id="left_cap">

		    <p class="homebutton"><a  href="/us/products/index.html" onclick="navTrack('otn','en','hnav','productsandservices');"><span>Products and Services</span></a></p>

			<div class="submenu three-columns" style="margin-left:0px;">

				<div class="left-column">

				    <dl>

					    <dt><a href="/us/products/index.html" onclick="navTrack('otn','en','hnav','productsandservices:products');">Products</a></dt>
												<dd><a href="/us/products/database/index.html" onclick="navTrack('otn','en','hnav','productsandservices:products:productsdatabase');">Oracle Database</a></dd>

												<dd><a href="/us/products/middleware/index.html" onclick="navTrack('otn','en','hnav','productsandservices:products:fusionmiddleware');">Oracle Fusion Middleware</a></dd>

												<dd><a href="/us/products/applications/index.html" onclick="navTrack('otn','en','hnav','productsandservices:products:productsapplications');">Oracle Applications</a></dd>

												<dd><a href="/us/products/servers-storage/index.html" onclick="navTrack('otn','en','hnav','productsandservices:products:infrastructure');">Server and Storage Systems</a></dd>

												<dd><a href="/us/products/tools/index.html" onclick="navTrack('otn','en','hnav','productsandservices:products:tools');">Development Tools</a></dd>

												<dd><a href="/us/products/ondemand/index.html" onclick="navTrack('otn','en','hnav','productsandservices:products:oracleondemand');">Oracle On Demand</a></dd>

												<dd><a href="http://crmondemand.oracle.com/en/index.html" onclick="navTrack('otn','en','hnav','productsandservices:products:oraclecrmondemand');">Oracle CRM On Demand</a></dd>

												<dd><a href="/products/product_list.html" onclick="navTrack('otn','en','hnav','productsandservices:products:productslist');">Product A-Z List</a></dd>

				    </dl>

				    <dl>

					    <dt><a href="/solutions/index.html" onclick="navTrack('otn','en','hnav','productsandservices:solutions');">Solutions</a></dt>
												<dd><a href="/us/technologies/java/index.html" onclick="navTrack('otn','en','hnav','productsandservices:solutions:java');">Java</a></dd>

												<dd><a href="/us/solutions/ent-performance-bi/index.html" onclick="navTrack('otn','en','hnav','productsandservices:solutions:bussinessIntelligence');">Business Intelligence</a></dd>

												<dd><a href="/us/solutions/ent-performance-bi/index.html" onclick="navTrack('otn','en','hnav','productsandservices:solutions:EntPerformancemangement');">Enterprise Performance <br>Management</a></dd>

												<dd><a href="/us/solutions/datawarehousing/index.html" onclick="navTrack('otn','en','hnav','productsandservices:solutions:datawarehousing');">Data Warehousing</a></dd>

												<dd><a href="/us/solutions/corporate-governance/index.html" onclick="navTrack('otn','en','hnav','productsandservices:solutions:corpgov');">Governance, Risk, and <br>Compliance</a></dd>

												<dd><a href="/us/solutions/midsize/index.html" onclick="navTrack('otn','en','hnav','productsandservices:solutions:formidsizecompanies');">For Midsize Companies</a></dd>

												<dd><a href="/solutions/index.html" onclick="navTrack('otn','en','hnav','productsandservices:solutions:seeallsolutions');"><span class='seeAll'>See All &hellip;</span></a></dd>

				    </dl>

				</div>
				<div class="right-colnoborder">
				    <dl>

					    <dt>Services</dt>
												<dd><a href="/us/support/software/advanced-customer-services/index.html" onclick="navTrack('otn','en','hnav','productsandservices:services:advancedcustomer');">Advanced Customer Services</a></dd>

												<dd><a href="/us/products/consulting/index.html" onclick="navTrack('otn','en','hnav','productsandservices:services:consulting');">Consulting</a></dd>

												<dd><a href="/us/products/financing/index.html" onclick="navTrack('otn','en','hnav','productsandservices:services:financing');">Financing</a></dd>

												<dd><a href="/us/products/ondemand/index.html" onclick="navTrack('otn','en','hnav','productsandservices:services:ondemand');">On Demand</a></dd>

												<dd><a href="/us/support/index.html" onclick="navTrack('otn','en','hnav','productsandservices:services:pandssupport');">Support</a></dd>

												<dd><a href="http://education.oracle.com/pls/web_prod-plq-dad/db_pages.getpage?page_id=3" onclick="navTrack('otn','en','hnav','productsandservices:services:oracleuniversity');">Oracle University</a></dd>

				    </dl>

				    <dl>

					    <dt><a href="/us/industries/index.html" onclick="navTrack('otn','en','hnav','productsandservices:industries');">Industries</a></dt>
												<dd><a href="/us/industries/communications/index.html" onclick="navTrack('otn','en','hnav','productsandservices:industries:communications');">Communications</a></dd>

												<dd><a href="/us/industries/education-and-research/018753.htm" onclick="navTrack('otn','en','hnav','productsandservices:industries:educationandresearch');">Education and Research</a></dd>

												<dd><a href="/us/industries/engineering-and-construction/index.html" onclick="navTrack('otn','en','hnav','productsandservices:industries:engineeringconstruction');">Engineering and Construction</a></dd>

												<dd><a href="/us/industries/financial-services/index.html" onclick="navTrack('otn','en','hnav','productsandservices:industries:financialservices');">Financial Services</a></dd>

												<dd><a href="/us/industries/retail/index.html" onclick="navTrack('otn','en','hnav','productsandservices:industries:retail');">Retail</a></dd>

												<dd><a href="/us/industries/index.html" onclick="navTrack('otn','en','hnav','productsandservices:industries:seeallindustries');"><span class='seeAll'>See All &hellip;</span></a></dd>

				    </dl>

				    <dl>

					    <dt><a href="/customers/index.html" onclick="navTrack('otn','en','hnav','productsandservices:pandsoraclecustomersuccess');">Oracle Customer Successes</a></dt>
				    </dl>

				    <dl>

					    <dt><a href="http://partner.oracle.com" onclick="navTrack('otn','en','hnav','productsandservices:pandspartners');">Partners</a></dt>
												<dd><a href="/partners/en/knowledge-zone/index.html" onclick="navTrack('otn','en','hnav','productsandservices:pandspartners:knowledgezone');">Knowledge Zones</a></dd>

												<dd><a href="/partners/secure/sales/sales-kits/" onclick="navTrack('otn','en','hnav','productsandservices:pandspartners:saleskits');">Sales Kits</a></dd>

												<dd><a href="/us/partnerships/solutions/index.html" onclick="navTrack('otn','en','hnav','productsandservices:pandspartners:pandsvalidatedintegrations');">Oracle Validated Integrations</a></dd>

				    </dl>

				</div>
				<div class="last-column">
				    <dl>

					    <div class='submenuhead'>
<div class='submenuhead submen' style='margin-bottom:18px;*margin-bottom:-10px;'><span>Spotlight</span>
<dl>
    <dd><a href='/us/technologies/cloud/index.htm' onclick='navTrack("ocom","en","hnav","productsandservices:spotlight:cloud computing");'>Cloud Computing</a></dd>
    <dd><a onclick='navTrack("ocom","en","hnav","productsandservices:spotlight:virtualization");' href='/us/technologies/virtualization/index.html'>Virtualization</a></dd>
    <dd><a onclick='navTrack("ocom","en","hnav","productsandservices:spotlight:fusion application");' href='/us/products/applications/fusion/index.html'>Oracle Fusion Applications</a></dd>
    <dd><a onclick='navTrack("ocom","en","hnav","productsandservices:spotlight:solaris 11");' href='/us/products/servers-storage/solaris/index.html'>Oracle Solaris 11</a></dd>
    <dd><a onclick='navTrack("ocom","en","hnav","productsandservices:spotlight:exalogic promo");' href='/us/products/middleware/exalogic/index.html'><img src='/ocom/groups/public/@ocom/documents/webcontent/exalogic_promo.jpg' width='166' height='87' border='0' alt='Marvel' style='*padding-bottom:10px;padding-top:10px;'></a></dd>
    <div class='submenuhead subbottomcenter'></div>
</dl>
</div>
</div>


				    </dl>

				    <dl>

					    <dt><a href="/us/corporate/Acquisitions/index.html" onclick="navTrack('otn','en','hnav','productsandservices:acquisitions');">Acquisitions</a></dt>
												<dd><a href="/us/sun/index.html" onclick="navTrack('otn','en','hnav','productsandservices:acquisitions:sun');">Sun</a></dd>

												<dd><a href="/products/middleware/bea.html" onclick="navTrack('otn','en','hnav','productsandservices:acquisitions:bea');">BEA</a></dd>

												<dd><a href="/hyperion/index.html" onclick="navTrack('otn','en','hnav','productsandservices:acquisitions:hyperion');">Hyperion</a></dd>

												<dd><a href="/us/products/applications/jd-edwards-enterpriseone/index.html" onclick="navTrack('otn','en','hnav','productsandservices:acquisitions:jdedwardsworld');">JD Edwards EnterpriseOne</a></dd>

												<dd><a href="/us/products/applications/peoplesoft-enterprise/index.html" onclick="navTrack('otn','en','hnav','productsandservices:acquisitions:peoplesoftentp');">PeopleSoft Enterprise</a></dd>

												<dd><a href="/us/products/applications/primavera/index.html" onclick="navTrack('otn','en','hnav','productsandservices:acquisitions:primavera');">Primavera</a></dd>

												<dd><a href="/us/corporate/Acquisitions/index.html" onclick="navTrack('otn','en','hnav','productsandservices:acquisitions:seeallacquisitions');"><span class='seeAll'>See All &hellip;</span></a></dd>

				    </dl>

				</div>

			    
			    <div class="bottomleft">
				<div class="threebottomcenter">
				    <div class="bottomright"> </div>
				</div>
			    </div>
		    </div>

		</li>

		<li class="top-level">

		    <p><a  href="/technetwork/indexes/downloads/index.html" onclick="navTrack('otn','en','hnav','downloads');"><span>Downloads</span></a></p>

			<div class="submenu three-columns">

				<div class="left-column">

				    <dl>

					    <dt><a href="/technetwork/indexes/downloads/index.html#database" onclick="navTrack('otn','en','hnav','downloads:database');">Databases</a></dt>
												<dd><a href="/technetwork/database/enterprise-edition/downloads/index.html" onclick="navTrack('otn','en','hnav','downloads:database:database11g');">Database 11<em>g</em></a></dd>

												<dd><a href="/technetwork/database/express-edition/downloads/index.html" onclick="navTrack('otn','en','hnav','downloads:database:expresseditiondownloads');">Database 10<em>g</em> Express Edition</a></dd>

												<dd><a href="http://www.mysql.com/downloads/" onclick="navTrack('otn','en','hnav','downloads:database:mysqldownloads');">MySQL</a></dd>

												<dd><a href="/technetwork/database/berkeleydb/downloads/index.html" onclick="navTrack('otn','en','hnav','downloads:database:berkeleydb');">Berkeley DB</a></dd>

												<dd><a href="/technetwork/database/features/instant-client/index-097480.html" onclick="navTrack('otn','en','hnav','downloads:database:instantclient');">Instant Client</a></dd>

												<dd><a href="/technetwork/developer-tools/apex/downloads/index.html" onclick="navTrack('otn','en','hnav','downloads:database:applicationexpressdownloads');">Application Express</a></dd>

												<dd><a href="/technetwork/indexes/downloads/index.html#database" onclick="navTrack('otn','en','hnav','downloads:database:seealldatabase');"><span class='seeAll'>See All &hellip;</span></a></dd>

				    </dl>

				    <dl>

					    <dt><a href="/technetwork/indexes/downloads/index.html#middleware" onclick="navTrack('otn','en','hnav','downloads:middleware');">Middleware</a></dt>
												<dd><a href="/technetwork/middleware/fusion-middleware/downloads/index.html" onclick="navTrack('otn','en','hnav','downloads:middleware:fusionmiddlewaredownloads');"> Fusion Middleware 11<em>g</em><br>(incl. WebLogic)</a></dd>

												<dd><a href="/technetwork/middleware/jrockit/downloads/index.html" onclick="navTrack('otn','en','hnav','downloads:middleware:jrockitdownloads');">JRockit</a></dd>

												<dd><a href="/technetwork/middleware/soasuite/downloads/index.html" onclick="navTrack('otn','en','hnav','downloads:middleware:soasuitedownloads');">SOA Suite</a></dd>

												<dd><a href="/technetwork/indexes/downloads/index.html#middleware" onclick="navTrack('otn','en','hnav','downloads:middleware:seeallmiddleware');"><span class='seeAll'>See All &hellip;</span></a></dd>

				    </dl>

				    <dl>

					    <dt><a href="/technetwork/indexes/downloads/index.html#em" onclick="navTrack('otn','en','hnav','downloads:enterprisemanagement');">Enterprise Management</a></dt>
												<dd><a href="/technetwork/oem/grid-control/downloads/index.html" onclick="navTrack('otn','en','hnav','downloads:enterprisemanagement:enterprisemanagergridcontrol');">Enterprise Manager</a></dd>

												<dd><a href="/technetwork/oem/downloads/index-084446.html" onclick="navTrack('otn','en','hnav','downloads:enterprisemanagement:applicationtestingsuite');">Application Testing Suite</a></dd>

												<dd><a href="/technetwork/indexes/downloads/index.html#em" onclick="navTrack('otn','en','hnav','downloads:enterprisemanagement:seeallenterprisemanagement');"><span class='seeAll'>See All &hellip;</span></a></dd>

				    </dl>

				</div>
				<div class="right-colnoborder">
				    <dl>

					    <dt><a href="/technetwork/indexes/downloads/index.html#servers" onclick="navTrack('otn','en','hnav','downloads:serversandstoragesystems');">Servers and Storage Systems</a></dt>
												<dd><a href="/technetwork/server-storage/solaris/downloads/index.html" onclick="navTrack('otn','en','hnav','downloads:serversandstoragesystems:solaris');">Oracle Solaris</a></dd>

												<dd><a href="http://edelivery.oracle.com/linux" onclick="navTrack('otn','en','hnav','downloads:serversandstoragesystems:enterpriselinuxandvm');">Oracle Linux and VM</a></dd>

												<dd><a href="http://www.sun.com/servers/blades/downloads.jsp" onclick="navTrack('otn','en','hnav','downloads:serversandstoragesystems:firmware');">Firmware</a></dd>

												<dd><a href="/technetwork/indexes/downloads/index.html#servers" onclick="navTrack('otn','en','hnav','downloads:serversandstoragesystems:seeallserversandstoragesystems');"><span class='seeAll'>See All &hellip;</span></a></dd>

				    </dl>

				    <dl>

					    <dt><a href="/technetwork/indexes/downloads/index.html#tools" onclick="navTrack('otn','en','hnav','downloads:developertools');">Developer Tools</a></dt>
												<dd><a href="/technetwork/developer-tools/sql-developer/downloads/index.html" onclick="navTrack('otn','en','hnav','downloads:developertools:sqldownloads');">Oracle SQL Developer</a></dd>

												<dd><a href="/technetwork/developer-tools/jdev/downloads/index.html" onclick="navTrack('otn','en','hnav','downloads:developertools:jdevdownloads');">JDeveloper and ADF</a></dd>

												<dd><a href="/technetwork/database/windows/downloads/index-101290.html" onclick="navTrack('otn','en','hnav','downloads:developertools:techdotnettoolsdownloads');">Developer Tools for Visual Studio</a></dd>

												<dd><a href="/technetwork/developer-tools/eclipse/downloads/index.html" onclick="navTrack('otn','en','hnav','downloads:developertools:enterprisepackforeclipsedownloads');">Enterprise Pack for Eclipse</a></dd>

												<dd><a href="http://netbeans.org/downloads/index.html" onclick="navTrack('otn','en','hnav','downloads:developertools:netbeansidedownloads');">NetBeans IDE</a></dd>

												<dd><a href="/technetwork/indexes/downloads/index.html#tools" onclick="navTrack('otn','en','hnav','downloads:developertools:seealldevelopertools');"><span class='seeAll'>See All &hellip;</span></a></dd>

				    </dl>

				    <dl>

					    <dt><a href="/technetwork/indexes/downloads/index.html#apps" onclick="navTrack('otn','en','hnav','downloads:applications');">Applications</a></dt>
												<dd><a href="http://edelivery.oracle.com/" onclick="navTrack('otn','en','hnav','downloads:applications:edelivery');">E-Business Suite, <br>PeopleSoft, JD Edwards, <br>Siebel CRM</a></dd>

												<dd><a href="/technetwork/apps-tech/index-097651.html" onclick="navTrack('otn','en','hnav','downloads:applications:agile');">Oracle Agile</a></dd>

												<dd><a href="/technetwork/apps-tech/index-095827.html" onclick="navTrack('otn','en','hnav','downloads:applications:autovue');">Oracle Autovue</a></dd>

												<dd><a href="/technetwork/indexes/downloads/index.html#apps" onclick="navTrack('otn','en','hnav','downloads:applications:seeallapplications');"><span class='seeAll'>See All &hellip;</span></a></dd>

				    </dl>

				</div>
				<div class="last-column">
				    <dl>

					    <div class='submenuhead'>
<div class='submenuhead submen' style='margin-bottom:18px;*margin-bottom:-10px;'><span>Popular Downloads</span>
<dl>
    <dd><a href='http://java.sun.com/javase/downloads/index.jsp' onclick='navTrack("ocom","en","hnav","downloads:populardownloads:javafordevelopersdownloads");'>Java for Developers</a></dd>
    <dd><a href='http://java.com/download' onclick='navTrack("ocom","en","hnav","downloads:populardownloads:javaforyourcomputerdownloads");'>Java for Your Computer</a></dd>
    <dd><a href='http://javafx.com/downloads/all.jsp' onclick='navTrack("ocom","en","hnav","downloads:populardownloads:javafxdownloads");'>JavaFX</a></dd>
    <dd><a href='/technetwork/server-storage/solaris/downloads/index.html' onclick='navTrack("ocom","en","hnav","downloads:populardownloads:solarisdownloads");'>Oracle Solaris</a></dd>
    <dd><a href='http://www.mysql.com/downloads/' onclick='navTrack("ocom","en","hnav","downloads:populardownloads:mysqldownloads");'>MySQL</a></dd>
    <dd><a href='/technetwork/middleware/fusion-middleware/downloads/index.html' onclick='navTrack("ocom","en","hnav","downloads:populardownloads:fusionmiddleware11gweblogicdownloads");'>Fusion Middleware 11<em>g</em></a></dd>
    <dd style='*margin-bottom:10px;'><a href='/technetwork/database/enterprise-edition/downloads/index.html' onclick='navTrack("ocom","en","hnav","downloads:populardownloads:database11gdownloads");'>Database 11<em>g</em></a></dd>
	<dd style='margin-bottom:0px;*margin-bottom:20px;*padding-bottom:-10px;'></dd>
    <div class='submenuhead subbottomcenter'></div>
</dl>
</div>
</div>


				    </dl>

				    <dl>

					    <dt><a href="http://oss.oracle.com/" onclick="navTrack('otn','en','hnav','downloads:freeopensourcesoftware');">Free Open Source Software</a></dt>
				    </dl>

				    <dl>

					    <dt><a href="/partners/secure/development/order-technology-software/020672.htm" onclick="navTrack('otn','en','hnav','downloads:partnerdemosoftware');">Partner Demo Software</a></dt>
				    </dl>

				</div>

			    
			    <div class="bottomleft">
				<div class="threebottomcenter">
				    <div class="bottomright"> </div>
				</div>
			    </div>
		    </div>

		</li>

		<li class="top-level">

		    <p><a  href="https://shop.oracle.com" onclick="navTrack('otn','en','hnav','store');"><span>Store</span></a></p>

			<div class="submenu two-columns">

				<div class="left-column">

				    <dl>

					    <dt><a href="https://shop.oracle.com/product/database" onclick="navTrack('otn','en','hnav','store:storedatabase');">Database</a></dt>
												<dd><a href="https://shop.oracle.com/product/oracledatabase" onclick="navTrack('otn','en','hnav','store:storedatabase:storeoracledatabase');">Oracle Database</a></dd>

												<dd><a href="https://shop.oracle.com/product/oracledatabasemediapack" onclick="navTrack('otn','en','hnav','store:storedatabase:storeoracledatabasemediapack');">Oracle Database Media Pack</a></dd>

												<dd><a href="https://shop.oracle.com/product/databasemanagementpacks" onclick="navTrack('otn','en','hnav','store:storedatabase:storeoracledatabasemanagementpack');">Oracle Database Management <br>Packs</a></dd>

												<dd><a href="https://shop.oracle.com/product/berkeleydb" onclick="navTrack('otn','en','hnav','store:storedatabase:storeberkeleydb');">Berkeley DB</a></dd>

												<dd><a href="https://shop.oracle.com/product/oracledatabaselite" onclick="navTrack('otn','en','hnav','store:storedatabase:storeoracledatabaselite');">Oracle Database Lite</a></dd>

												<dd><a href="https://shop.oracle.com/product/database" onclick="navTrack('otn','en','hnav','store:storedatabase:storedatabaseseeall');"><span class='seeAll'>See All &hellip;</span></a></dd>

				    </dl>

				    <dl>

					    <dt><a href="https://shop.oracle.com/product/infrastructure" onclick="navTrack('otn','en','hnav','store:storeinfrastructure');">Infrastructure</a></dt>
												<dd><a href="https://shop.oracle.com/product/enterpriselinux" onclick="navTrack('otn','en','hnav','store:storeinfrastructure:storeenterpriselinux');">Oracle Linux</a></dd>

												<dd><a href="https://shop.oracle.com/product/virtualization" onclick="navTrack('otn','en','hnav','store:storeinfrastructure:storevirtualization');">Virtualization</a></dd>

				    </dl>

				    <dl>

					    <dt><a href="https://shop.oracle.com/product/applications" onclick="navTrack('otn','en','hnav','store:storeapplications');">Applications</a></dt>
												<dd><a href="https://shop.oracle.com/product/oraclecrystalball" onclick="navTrack('otn','en','hnav','store:storeapplications:storeoraclecrystalball');">Oracle Crystal Ball</a></dd>

												<dd><a href="https://shop.oracle.com/product/autovue" onclick="navTrack('otn','en','hnav','store:storeapplications:storeoracleautovue');">Autovue</a></dd>

												<dd><a href="https://shop.oracle.com/product/primavera" onclick="navTrack('otn','en','hnav','store:storeapplications:storeoracleprimavera');">Primavera</a></dd>

				    </dl>

				</div>
				<div class="right-column">
				    <dl>

					    <dt><a href="https://shop.oracle.com/product/enterprisemanagement" onclick="navTrack('otn','en','hnav','store:storeenterprisemanagement');">Enterprise Management</a></dt>
												<dd><a href="https://shop.oracle.com/product/databasemanagement" onclick="navTrack('otn','en','hnav','store:storeenterprisemanagement:storedatabasemanagement');">Database Management</a></dd>

												<dd><a href="https://shop.oracle.com/product/applicationsmanagement" onclick="navTrack('otn','en','hnav','store:storeenterprisemanagement:storeapplicationsmanagement');">Applications Management</a></dd>

												<dd><a href="https://shop.oracle.com/product/businessintelligencemanagement" onclick="navTrack('otn','en','hnav','store:storeenterprisemanagement:storebusinessintelligencemanagement');">Business Intelligence Management</a></dd>

				    </dl>

				    <dl>

					    <dt><a href="https://shop.oracle.com/product/middleware" onclick="navTrack('otn','en','hnav','store:storemiddleware');">Middleware</a></dt>
												<dd><a href="https://shop.oracle.com/product/oracleweblogicserverstandardedition" onclick="navTrack('otn','en','hnav','store:storemiddleware:storeoracleweblogicserver');">Oracle WebLogic Server</a></dd>

												<dd><a href="https://shop.oracle.com/product/applicationserverapplicationgrid" onclick="navTrack('otn','en','hnav','store:storemiddleware:storeapplicationserverapplicationgrid');">Application Server and Application <br>Grid</a></dd>

												<dd><a href="https://shop.oracle.com/product/businessintelligencetechnology" onclick="navTrack('otn','en','hnav','store:storemiddleware:storebusinessintelligencetechnology');">Business Intelligence Technology</a></dd>

												<dd><a href="https://shop.oracle.com/product/developmenttools" onclick="navTrack('otn','en','hnav','store:storemiddleware:storedevelopmenttools');">Development Tools</a></dd>

												<dd><a href="https://shop.oracle.com/product/dataintegration" onclick="navTrack('otn','en','hnav','store:storemiddleware:storedataintegration');">Data Integration</a></dd>

												<dd><a href="https://shop.oracle.com/product/middleware" onclick="navTrack('otn','en','hnav','store:storemiddleware:storemiddlewareseeall');"><span class='seeAll'>See All &hellip;</span></a></dd>

				    </dl>

				    <dl>

					    <dt><a href="/store" onclick="navTrack('otn','en','hnav','store:storeseeall');">All Products</a></dt>
				    </dl>

				    <dl>

					    <dt><a href="/corporate/pricing/pricelists.html" onclick="navTrack('otn','en','hnav','store:corporatepricing');">Oracle Price Lists</a></dt>
				    </dl>

				    <dl>

					    <dt><a href="http://www.oracle.com/partners/index.html" onclick="navTrack('otn','en','hnav','store:storepartners');"><span style=margin-top:20px;>Partners</span></a></dt>
												<dd><a href="/partners/secure/sales/olsa-online/" onclick="navTrack('otn','en','hnav','store:storepartners:storelicenseandsale');">License and Sales Agreements</a></dd>

												<dd><a href="/partners/secure/sales/partner-ordering-portal/020782.htm" onclick="navTrack('otn','en','hnav','store:storepartners:storeorderingportal');">Ordering Portal (POP)</a></dd>

												<dd><a href="/partners/en/how-to-do-business/distribution-agreements/index.html" onclick="navTrack('otn','en','hnav','store:storepartners:storedistributeoracleproducts');">Distribute Oracle Products</a></dd>

												<dd><a href="/partners/en/how-to-do-business/register-referrals/index.html" onclick="navTrack('otn','en','hnav','store:storepartners:storeregisterareferral');">Register a Referral</a></dd>

												<dd><a href="/partners/secure/sales/pricing-licensing/021511.htm" onclick="navTrack('otn','en','hnav','store:storepartners:storepricing');">Pricing and Licensing</a></dd>

				    </dl>

				</div>

			    
			    <div class="bottomleft">
				<div class="bottomcenter">
				    <div class="bottomright"> </div>
				</div>
			    </div>
		    </div>

		</li>

		<li class="top-level">

		    <p><a  href="/us/support/index.html" onclick="navTrack('otn','en','hnav','support');"><span>Support</span></a></p>

			<div class="submenu two-columns">

				<div class="left-column">

				    <dl>

					    <dt><a href="http://www.oracle.com/goto/servicescatalog/index.html" onclick="navTrack('otn','en','hnav','support:supportservices');">Support Services</a></dt>
												<dd><a href="/us/support/software/premier/index.html" onclick="navTrack('otn','en','hnav','support:supportservices:supportpremier');">Premier Support</a></dd>

												<dd><a href="/us/support/software/advanced-customer-services/exadata-services-068601.html" onclick="navTrack('otn','en','hnav','support:supportservices:supportexadata');">Exadata Support</a></dd>

												<dd><a href="/us/technologies/virtualization/index.html" onclick="navTrack('otn','en','hnav','support:supportservices:virtualization');">Virtualization</a></dd>

												<dd><a href="/us/technologies/linux/index.html" onclick="navTrack('otn','en','hnav','support:supportservices:unbreakablelinux');">Unbreakable Linux</a></dd>

												<dd><a href="/us/support/software/advanced-customer-services/index.html" onclick="navTrack('otn','en','hnav','support:supportservices:advancedcustomerservices');">Advanced Customer Services</a></dd>

												<dd><a href="http://www.oracle.com/goto/servicescatalog/index.html" onclick="navTrack('otn','en','hnav','support:supportservices:seeallsupportservices');"><span class='seeAll'>See All &hellip;</span></a></dd>

				    </dl>

				    <dl>

					    <dt>Support Resources</dt>
												<dd><a href="/us/corporate/acquisitions/index.html" onclick="navTrack('otn','en','hnav','support:supportresources:acquiredcompanyinformation');">Acquired Company Information</a></dd>

												<dd><a href="http://www.oracle.com/goto/customersuccess/index.html" onclick="navTrack('otn','en','hnav','support:supportresources:customersuccessassessment');">Customer Success Assessment</a></dd>

												<dd><a href="/us/support/lifetime-support/index.html" onclick="navTrack('otn','en','hnav','support:supportresources:lifetimesupportpolicies');">Lifetime Support Policies</a></dd>

												<dd><a href="/us/technologies/linux/index.html" onclick="navTrack('otn','en','hnav','support:supportresources:linuxtechnologycenter');">Linux Technology Center</a></dd>

												<dd><a href="https://communities.oracle.com/portal/server.pt/community/support/219" onclick="navTrack('otn','en','hnav','support:supportresources:myoraclesupportcommunity');">My Oracle Support Community</a></dd>

												<dd><a href="/us/support/policies/index.html" onclick="navTrack('otn','en','hnav','support:supportresources:technicalsupportpolicies');">Technical Support Policies</a></dd>

												<dd><a href="/technology/products/vm/index.html" onclick="navTrack('otn','en','hnav','support:supportresources:virtualizationtechnologycenter');">Virtualization Technology Center</a></dd>

				    </dl>

				</div>
				<div class="right-column">
				    <dl>

					    <dt>Support Assistance</dt>
												<dd><a href="http://support.oracle.com" onclick="navTrack('otn','en','hnav','support:supportassistance:myoraclesupport');">My Oracle Support</a></dd>

												<dd><a href="/us/support/support-integration/index.html" onclick="navTrack('otn','en','hnav','support:supportassistance:supportintegration');">Acquired Company Support</a></dd>

												<dd><a href="/us/support/contact-068555.html" onclick="navTrack('otn','en','hnav','support:supportassistance:supportcontacts');">Global Support Contacts</a></dd>

				    </dl>

				    <dl>

					    <dt><a href="https://support.oracle.com/CSP/ui/flash.html#tab=PatchHomePage%28page=PatchHomePage&id=g1ws8maj%28%29%29" onclick="navTrack('otn','en','hnav','support:downloadpatches');">Download Patches</a></dt>
				    </dl>

				    <dl>

					    <dt><a href="https://support.oracle.com/CSP/ui/flash.html#tab=KBHome(page=KBHome&id=g1txk01p())" onclick="navTrack('otn','en','hnav','support:searchsupportknowledgedatabase');">Search Support Knowledge<br>Database</a></dt>
				    </dl>

				    <dl>

					    <dt><a href=" https://support.oracle.com/CSP/ui/flash.html#tab=SRHome(page=SRHome&id=g1txr1mm())" onclick="navTrack('otn','en','hnav','support:createorupdateservicerequest');">Create or Update Service<br>Request</a></dt>
				    </dl>

				    <dl>

					    <dt><a href="/technology/documentation/index.html" onclick="navTrack('otn','en','hnav','support:documentation');">Documentation</a></dt>
												<dd><a href="/pls/db92/db92.federated_search" onclick="navTrack('otn','en','hnav','support:documentation:searchdocumentation');">Search Documentation</a></dd>

												<dd><a href="/technology/documentation/index.html#previous" onclick="navTrack('otn','en','hnav','support:documentation:documentationarchive');">Documentation Archive</a></dd>

												<dd><a href="/technology/documentation/index.html" onclick="navTrack('otn','en','hnav','support:documentation:seealldocumentation');"><span class='seeAll'>See All &hellip;</span></a></dd>

				    </dl>

				    <dl>

					    <dt><a href="http://partner.oracle.com" onclick="navTrack('otn','en','hnav','support:supportpartner');">Partners</a></dt>
												<dd><a href="/partners/secure/support/index.html" onclick="navTrack('otn','en','hnav','support:supportpartner:salessupport');">Support</a></dd>

												<dd><a href="/partners/secure/sales/resell-support/index.htm" onclick="navTrack('otn','en','hnav','support:supportpartner:resellsupport');">Resell Oracle Support</a></dd>

												<dd><a href="/partners/en/opn-program/membership-resources/business-center/index.html" onclick="navTrack('otn','en','hnav','support:supportpartner:talktopartner');">Talk to a Partner Expert</a></dd>

				    </dl>

				</div>

			    
			    <div class="bottomleft">
				<div class="bottomcenter">
				    <div class="bottomright"> </div>
				</div>
			    </div>
		    </div>

		</li>

		<li class="top-level">

		    <p><a  href="http://education.oracle.com/" onclick="navTrack('otn','en','hnav','education');"><span>Education</span></a></p>

			<div class="submenu two-columns">

				<div class="left-column">

				    <dl>

					    <dt><a href="http://education.oracle.com/pls/web_prod-plq-dad/db_pages.getpage?page_id=392" onclick="navTrack('otn','en','hnav','education:courseschedule');">Course Schedule</a></dt>
				    </dl>

				    <dl>

					    <dt><a href="http://education.oracle.com/pls/web_prod-plq-dad/db_pages.getpage?page_id=14 " onclick="navTrack('otn','en','hnav','education:producttraining');">Product Training</a></dt>
				    </dl>

				    <dl>

					    <dt><a href="http://education.oracle.com/pls/web_prod-plq-dad/db_pages.getpage?page_id=69" onclick="navTrack('otn','en','hnav','education:trainingformats');">Training Formats</a></dt>
												<dd><a href="http://education.oracle.com/pls/web_prod-plq-dad/db_pages.getpage?page_id=33 " onclick="navTrack('otn','en','hnav','education:trainingformats:classroom');">Classroom</a></dd>

												<dd><a href="http://education.oracle.com/pls/web_prod-plq-dad/db_pages.getpage?page_id=233 " onclick="navTrack('otn','en','hnav','education:trainingformats:livevirtual');">Live Virtual</a></dd>

												<dd><a href="http://education.oracle.com/pls/web_prod-plq-dad/db_pages.getpage?page_id=35" onclick="navTrack('otn','en','hnav','education:trainingformats:selfstudycdrom');">Self-Study CD-ROM</a></dd>

												<dd><a href="http://education.oracle.com/pls/web_prod-plq-dad/db_pages.getpage?page_id=160" onclick="navTrack('otn','en','hnav','education:trainingformats:selfpacedonline');">Self-Paced Online</a></dd>

												<dd><a href="http://education.oracle.com/pls/web_prod-plq-dad/db_pages.getpage?page_id=134" onclick="navTrack('otn','en','hnav','education:trainingformats:useradoptionservices');">User Adoption Services</a></dd>

												<dd><a href="http://education.oracle.com/pls/web_prod-plq-dad/db_pages.getpage?page_id=69" onclick="navTrack('otn','en','hnav','education:trainingformats:trainingseeall');"><span class='seeAll'>See All &hellip;</span></a></dd>

				    </dl>

				    <dl>

					    <dt><a href="http://education.oracle.com/pls/web_prod-plq-dad/db_pages.getpage?page_id=15" onclick="navTrack('otn','en','hnav','education:learningpaths');">Learning Paths</a></dt>
				    </dl>

				    <dl>

					    <dt><a href="http://education.oracle.com/pls/web_prod-plq-dad/db_pages.getjobpage?page_id=306&p_jobrole_id=1" onclick="navTrack('otn','en','hnav','education:trainingbyjobrole');">Training by Job Role</a></dt>
				    </dl>

				</div>
				<div class="right-column">
				    <dl>

					    <dt><a href="http://education.oracle.com/pls/web_prod-plq-dad/db_pages.getpage?page_id=39" onclick="navTrack('otn','en','hnav','education:certificationprograms');">Certification Program</a></dt>
												<dd><a href="http://education.oracle.com/pls/web_prod-plq-dad/db_pages.getpage?page_id=73" onclick="navTrack('otn','en','hnav','education:certificationprograms:becomecertified');">Become Certified</a></dd>

												<dd><a href="http://education.oracle.com/pls/web_prod-plq-dad/db_pages.getpage?page_id=141" onclick="navTrack('otn','en','hnav','education:certificationprograms:certificationpaths');">Certification Paths</a></dd>

												<dd><a href="http://education.oracle.com/pls/web_prod-plq-dad/db_pages.getpage?page_id=156" onclick="navTrack('otn','en','hnav','education:certificationprograms:purchasevoucher');">Purchase a Voucher</a></dd>

												<dd><a href="http://education.oracle.com/pls/web_prod-plq-dad/db_pages.getpage?page_id=39" onclick="navTrack('otn','en','hnav','education:certificationprograms:educationseeall');"><span class='seeAll'>See All &hellip;</span></a></dd>

				    </dl>

				    <dl>

					    <dt><a href="http://education.oracle.com/pls/web_prod-plq-dad/db_pages.getpage?page_id=317" onclick="navTrack('otn','en','hnav','education:traininglocations');">Training Locations</a></dt>
				    </dl>

				    <dl>

					    <dt><a href="http://education.oracle.com/pls/web_prod-plq-dad/db_pages.getpage?page_id=225" onclick="navTrack('otn','en','hnav','education:contactoracleuniversity');">Contact Oracle University</a></dt>
				    </dl>

				    <dl>

					    <dt><a href="/partners/" onclick="navTrack('otn','en','hnav','education:educationpartners');">Partners</a></dt>
												<dd><a href="/partners/en/most-popular-resources/028916.htm" onclick="navTrack('otn','en','hnav','education:educationpartners:educationenablement');">Education and Enablement</a></dd>

												<dd><a href="/partners/en/knowledge-zone/index.html" onclick="navTrack('otn','en','hnav','education:educationpartners:partnerknowledgezone');">Knowledge Zones</a></dd>

				    </dl>

				</div>

			    
			    <div class="bottomleft">
				<div class="bottomcenter">
				    <div class="bottomright"> </div>
				</div>
			    </div>
		    </div>

		</li>

		<li class="top-level">

		    <p><a  href="/partners/index.html" onclick="navTrack('otn','en','hnav','partners');"><span>Partners</span></a></p>

			<div class="submenu two-columns">

				<div class="left-column">

				    <dl>

					    <dt><a href="http://solutions.oracle.com/" onclick="navTrack('otn','en','hnav','partners:opnfindparter');">Find an Oracle Partner</a></dt>
												<dd><a href="/us/partnerships/solutions/index.html" onclick="navTrack('otn','en','hnav','partners:opnfindparter:oraclevalidatedintegrations');">Oracle Validated Integrations</a></dd>

				    </dl>

				    <dl>

					    <dt><a href="/partners/en/index.html" onclick="navTrack('otn','en','hnav','partners:opnexplorepartnerprogram');">Explore Partner Programs</a></dt>
				    </dl>

				    <dl>

					    <dt><a href="/partners/en/opn-program/index.html" onclick="navTrack('otn','en','hnav','partners:opnwhypartner');">Why Partner</a></dt>
												<dd><a href="/partners/en/opn-program/membership-resources/index.html" onclick="navTrack('otn','en','hnav','partners:opnwhypartner:opnmembershipresources');">Membership Resources</a></dd>

												<dd><a href="/partners/en/opn-program/opn-details-by-levels/index.html" onclick="navTrack('otn','en','hnav','partners:opnwhypartner:opnpartnerlevels');">Partner Levels</a></dd>

												<dd><a href="/partners/en/opn-program/specialize/index.html" onclick="navTrack('otn','en','hnav','partners:opnwhypartner:opnspecializationoverview');">Specialization Overview</a></dd>

				    </dl>

				    <dl>

					    <dt><a href="/partners/en/join-now/index.html" onclick="navTrack('otn','en','hnav','partners:opnbecomepartner');">Become a Partner</a></dt>
				    </dl>

				</div>
				<div class="right-column">
				    <dl>

					    <dt><a href="/partners/en/knowledge-zone/index.html" onclick="navTrack('otn','en','hnav','partners:opnknowledgezone');">Knowledge Zones</a></dt>
												<dd><a href="/partners/en/knowledge-zone/database/index.html" onclick="navTrack('otn','en','hnav','partners:opnknowledgezone:opndatabase');">Database</a></dd>

												<dd><a href="/partners/en/knowledge-zone/middleware/index.html" onclick="navTrack('otn','en','hnav','partners:opnknowledgezone:opnmiddleware');">Middleware</a></dd>

												<dd><a href="/partners/en/knowledge-zone/applications/index.html" onclick="navTrack('otn','en','hnav','partners:opnknowledgezone:opnapplications');">Applications</a></dd>

												<dd><a href="/partners/en/knowledge-zone/server-storage/index.html" onclick="navTrack('otn','en','hnav','partners:opnknowledgezone:opnserversandstoragesystems');">Server and Storage Systems</a></dd>

												<dd><a href="/partners/en/knowledge-zone/industries/index.html" onclick="navTrack('otn','en','hnav','partners:opnknowledgezone:opnindustries');">Industries</a></dd>

				    </dl>

				    <dl>

					    <dt><a href="/partners/en/how-to-do-business/index.html" onclick="navTrack('otn','en','hnav','partners:opndobusinesswithoracle');">Do Business With Oracle</a></dt>
				    </dl>

				    <dl>

					    <dt><a href="/partners/en/opn-program/membership-resources/business-center/index.html" onclick="navTrack('otn','en','hnav','partners:opntalktopartner');">Talk to a Partner Expert</a></dt>
				    </dl>

				    <dl>

					    <dt><a href="http://events.oracle.com/search/search?group=Events&keyword=OPN+Only" onclick="navTrack('otn','en','hnav','partners:opnfindevents');">Partner-Only Events</a></dt>
				    </dl>

				     </div>
				     </div>
				     <div class="submenu two-columns divider">
					   <div class="heading_hornav">Partners <span>(login required)</span></div><div class="lock"><img src="/ocom/groups/systemobject/@mktg_admin/documents/digitalasset/opn-login-required-lock.png"></div>
					   <span class="image_right">
					   <!--spacer-->
					   </span><br>
					   <div class="left-column">
				    <dl>

					    <dt><a href="/partners/en/most-popular-resources/028916.htm" onclick="navTrack('otn','en','hnav','partners:opneducation');">Education and Enablement</a></dt>
												<dd><a href="https://competencycenter.oracle.com/opncc/home.cc" onclick="navTrack('otn','en','hnav','partners:opneducation:opncompetencycenter');">Competency Center</a></dd>

				    </dl>

				    <dl>

					    <dt><a href="/partners/secure/sales/" onclick="navTrack('otn','en','hnav','partners:opnsalesresources');">Sales Resources</a></dt>
												<dd><a href="/partners/secure/sales/pricing-licensing/" onclick="navTrack('otn','en','hnav','partners:opnsalesresources:opnpricingandlicensing');">Pricing and Licensing</a></dd>

												<dd><a href="/partners/secure/sales/sales-kits/" onclick="navTrack('otn','en','hnav','partners:opnsalesresources:opnsaleskits');">Sales Kits</a></dd>

												<dd><a href="/partners/secure/sales/partner-ordering-portal/020782.htm" onclick="navTrack('otn','en','hnav','partners:opnsalesresources:opnorderingportal');">Ordering Portal (POP)</a></dd>

												<dd><a href="/partners/secure/sales/olsa-online/" onclick="navTrack('otn','en','hnav','partners:opnsalesresources:opnlicenseandsalesagreements');">License and Sales Agreements</a></dd>

				    </dl>

				    <dl>

					    <dt><a href="/partners/secure/marketing/" onclick="navTrack('otn','en','hnav','partners:opnmarketingresources');">Marketing Resources</a></dt>
												<dd><a href="/partners/secure/marketing/download-logos/" onclick="navTrack('otn','en','hnav','partners:opnmarketingresources:opndownloadlogos');">Download Logos</a></dd>

												<dd><a href="http://solutions.oracle.com/portal/page/portal/OPN/sol_cat_wrapper" onclick="navTrack('otn','en','hnav','partners:opnmarketingresources:opnmanagesolutionscatalog');">Manage Solutions Catalog</a></dd>

												<dd><a href="http://www.oracle.com/go/?&src=4020042&Act=31" onclick="navTrack('otn','en','hnav','partners:opnmarketingresources:opnsubmitsuccessstory');">Submit Success Story</a></dd>

				    </dl>

				    <dl>

					    <dt><a href="/partners/secure/membership/" onclick="navTrack('otn','en','hnav','partners:opnmanagepartneraccount');">Manage Membership</a></dt>
				    </dl>

				</div>
				<div class="right-column">
				    <dl>

					    <dt><a href="/partners/secure/news/" onclick="navTrack('otn','en','hnav','partners:opnnewsandevents');">Partner News and Events</a></dt>
				    </dl>

				    <dl>

					    <dt><a href="/partners/secure/support/" onclick="navTrack('otn','en','hnav','partners:opnsupport');">Partner Support</a></dt>
				    </dl>

				    <dl>

					    <dt><a href="/partners/secure/development/" onclick="navTrack('otn','en','hnav','partners:opndevelopment');">Partner Developer Tools</a></dt>
				    </dl>

				</div>

			    
				<div class="partner_bottomleft">
				<div class="partner_bottomcenter">
				    <div class="partner_bottomright"> </div>
				</div>
			    </div>
		    </div>

		</li>

		<li class="top-level">

		    <p><a  href="/us/corporate/index.html" onclick="navTrack('otn','en','hnav','about');"><span>About</span></a></p>

			<div class="submenu three-columns anchor-right">

				<div class="left-column">

				    <dl>

					    <dt><a href="/us/corporate/index.html" onclick="navTrack('otn','en','hnav','about:companyinformation');">Company Information</a></dt>
												<dd><a href="/corporate/execs_content.html" onclick="navTrack('otn','en','hnav','about:companyinformation:corporateexecutives');">Executives</a></dd>

												<dd><a href="/corporate/board.html" onclick="navTrack('otn','en','hnav','about:companyinformation:corporateboardofdirectors');">Board of Directors</a></dd>

												<dd><a href="/corporate/investor_relations/CorpGov.html" onclick="navTrack('otn','en','hnav','about:companyinformation:corporateinvestorrelationscorpgov');">Corporate Governance</a></dd>

												<dd><a href="/services/insight/index.html" onclick="navTrack('otn','en','hnav','about:companyinformation:corporateservicesinsight');">Oracle Insight</a></dd>

												<dd><a href="/innovation/index.html" onclick="navTrack('otn','en','hnav','about:companyinformation:corporateinnovation');">Innovation</a></dd>

												<dd><a href="/corporate/story.html" onclick="navTrack('otn','en','hnav','about:companyinformation:corporatehistory');">History</a></dd>

				    </dl>

				    <dl>

					    <dt><a href="/corporate/employment/index.html" onclick="navTrack('otn','en','hnav','about:corporateemployment');">Careers</a></dt>
				    </dl>

				    <dl>

					    <dt><a href="/corporate/analyst/index.html" onclick="navTrack('otn','en','hnav','about:corporateanalystrelations');">Analyst Relations</a></dt>
				    </dl>

				    <dl>

					    <dt><a href="/corporate/investor_relations/index.html" onclick="navTrack('otn','en','hnav','about:corporateinvestorrelations');">Investor Relations</a></dt>
				    </dl>

				    <dl>

					    <dt><a href="/us/corporate/Acquisitions/index.html" onclick="navTrack('otn','en','hnav','about:corporateacquisitions');">Acquisitions</a></dt>
				    </dl>

				    <dl>

					    <dt><a href="/solutions/thoughtleadership/index.html" onclick="navTrack('otn','en','hnav','about:thoughtleadership');">Thought Leadership</a></dt>
				    </dl>

				</div>
				<div class="right-colnoborder">
				    <dl>

					    <dt><a href="/us/corporate/index.html#news" onclick="navTrack('otn','en','hnav','about:newsandevents');">News and Events</a></dt>
												<dd><a href="http://events.oracle.com/search/search?group=Events&keyword=" onclick="navTrack('otn','en','hnav','about:newsandevents:events');">Events</a></dd>

												<dd><a href="/us/corporate/press/index.html" onclick="navTrack('otn','en','hnav','about:newsandevents:pressroom');">Newsroom</a></dd>

												<dd><a href="/oramag/index.html" onclick="navTrack('otn','en','hnav','about:newsandevents:magazine');">Oracle Magazine</a></dd>

												<dd><a href="/profit/index.html" onclick="navTrack('otn','en','hnav','about:newsandevents:profit');">Profit Magazine</a></dd>

												<dd><a href="/newsletters/index.html" onclick="navTrack('otn','en','hnav','about:newsandevents:newsletters');">Oracle Newsletters</a></dd>

												<dd><a href="/us/corporate/publishing/index.html" onclick="navTrack('otn','en','hnav','about:newsandevents:corporatepublishing');">Oracle Publishing</a></dd>

												<dd><a href="/timeline/index.html" onclick="navTrack('otn','en','hnav','about:newsandevents:corporatetimeline');">Oracle Timeline</a></dd>

												<dd><a href="/corporate/bmw-oracle-racing.html" onclick="navTrack('otn','en','hnav','about:newsandevents:corporatebmworacleracing');">BMW ORACLE Racing</a></dd>

				    </dl>

				    <dl>

					    <dt><a href="/customers/index.html" onclick="navTrack('otn','en','hnav','about:aboutoraclecustomersuccess');">Oracle Customer Successes</a></dt>
				    </dl>

				    <dl>

					    <dt><a href="/partners/index.html" onclick="navTrack('otn','en','hnav','about:aboutpartners');">Partners</a></dt>
												<dd><a href="http://opnevents.oracle.com/" onclick="navTrack('otn','en','hnav','about:aboutpartners:aboutpartneronlyevents');">Partner-Only Events</a></dd>

												<dd><a href="/partners/secure/news/worldwide-opn-newsletter/" onclick="navTrack('otn','en','hnav','about:aboutpartners:aboutnewsletters');">Newsletters</a></dd>

				    </dl>

				</div>
				<div class="last-column">
				    <dl>

					    <div class='submenuhead'>
<div class='submenuhead submen'><span>Spotlight</span>
<dl>
    <dd><a onclick='navTrack("ocom","en","hnav","about:spotlight:engineered_promo");' href='/us/corporate/features/engineered-173370.html'><img src='/ocom/groups/public/@ocom/documents/webcontent/engineered_promo.gif' width='166' height='87' border='0' alt='FPO'></a></dd>    
    <div class='submenuhead subbottomcenter'></div>
</dl>
</div>
</div>


				    </dl>

				</div>

			    
			    <div class="bottomleft">
				<div class="threebottomcenter">
				    <div class="bottomright"> </div>
				</div>
			    </div>
		    </div>

		</li>

		<li class="top-level" id="oracleTechNetwork">

		    <p><a  class="noimg"  href="http://www.oracle.com/technetwork/index.html" onclick="navTrack('otn','en','hnav','oracletechnologynetwork');"><span>Oracle Technology Network</span></a></p>

			<div class="submenu two-columns anchor-right">

				<div class="left-column">

				    <dl>

					    <dt><a href="/technetwork/java/index.html" onclick="navTrack('otn','en','hnav','oracletechnologynetwork:otnjavadevelopers');">Java Developers</a></dt>
				    </dl>

				    <dl>

					    <dt><a href="/technetwork/dbadev/index.html" onclick="navTrack('otn','en','hnav','oracletechnologynetwork:otndatabaseadminsanddevelopers');">Database Admins and <br>Developers</a></dt>
				    </dl>

				    <dl>

					    <dt><a href="/technetwork/systems/index.html" onclick="navTrack('otn','en','hnav','oracletechnologynetwork:otnsystemadminsanddevelopers');">System Admins and Developers</a></dt>
				    </dl>

				    <dl>

					    <dt><a href="/technetwork/architect/index.html" onclick="navTrack('otn','en','hnav','oracletechnologynetwork:otnarchitects');">Architects</a></dt>
				    </dl>

				    <dl>

					    <dt><a href="/technetwork/community/join/overview/index.html" onclick="navTrack('otn','en','hnav','oracletechnologynetwork:joinotn');">Become a Member</a></dt>
				    </dl>

				    <dl>

					    <dt><a href="/technetwork/indexes/downloads/index.html" onclick="navTrack('otn','en','hnav','oracletechnologynetwork:otndownloads');">Downloads</a></dt>
												<dd><a href="/technetwork/database/enterprise-edition/downloads/index.html" onclick="navTrack('otn','en','hnav','oracletechnologynetwork:otndownloads:otndatabase');">Database</a></dd>

												<dd><a href="/technetwork/middleware/fusion-middleware/downloads/index.html" onclick="navTrack('otn','en','hnav','oracletechnologynetwork:otndownloads:otnfusionmiddleware');">Oracle Fusion Middleware</a></dd>

												<dd><a href="/technetwork/oem/grid-control/downloads/index.html" onclick="navTrack('otn','en','hnav','oracletechnologynetwork:otndownloads:otnenterprisemanager');">Oracle Enterprise Manager</a></dd>

												<dd><a href="/technetwork/developer-tools/index.html" onclick="navTrack('otn','en','hnav','oracletechnologynetwork:otndownloads:otndeveloperstool');">Developer Tools</a></dd>

												<dd><a href="/technetwork/indexes/downloads/index.html#java" onclick="navTrack('otn','en','hnav','oracletechnologynetwork:otndownloads:otnsunjava');">Java</a></dd>

												<dd><a href="/technetwork/indexes/downloads/index.html" onclick="navTrack('otn','en','hnav','oracletechnologynetwork:otndownloads:otnseeall');"><span class='seeAll'>See All &hellip;</span></a></dd>

				    </dl>

				    <dl>

					    <dt><a href="/technetwork/indexes/documentation/index.html" onclick="navTrack('otn','en','hnav','oracletechnologynetwork:otndocumentation');">Documentation</a></dt>
												<dd><a href="/technetwork/database/enterprise-edition/documentation/index.html" onclick="navTrack('otn','en','hnav','oracletechnologynetwork:otndocumentation:otndocumentdatabase');">Database</a></dd>

												<dd><a href="/technetwork/middleware/fusion-middleware/documentation/index.html" onclick="navTrack('otn','en','hnav','oracletechnologynetwork:otndocumentation:otndocumentfusionmiddleware');">Oracle Fusion Middleware</a></dd>

												<dd><a href="/technetwork/oem/grid-control/documentation/index.html" onclick="navTrack('otn','en','hnav','oracletechnologynetwork:otndocumentation:otndocumententerprisemanager');">Oracle Enterprise Manager</a></dd>

												<dd><a href="/technetwork/apps-tech/documentation/index.html" onclick="navTrack('otn','en','hnav','oracletechnologynetwork:otndocumentation:otndocumentappstechnology');">Applications Technology</a></dd>

												<dd><a href="/sundocs" onclick="navTrack('otn','en','hnav','oracletechnologynetwork:otndocumentation:otndocumentsun');">Sun Documentation</a></dd>

												<dd><a href="/technetwork/indexes/documentation/index.html" onclick="navTrack('otn','en','hnav','oracletechnologynetwork:otndocumentation:otndocumentseeall');"><span class='seeAll'>See All &hellip;</span></a></dd>

				    </dl>

				    <dl>

					    <dt><a href="/technetwork/articles/index.html" onclick="navTrack('otn','en','hnav','oracletechnologynetwork:otnarticles');">Articles</a></dt>
				    </dl>

				    <dl>

					    <dt><a href="http://apex.oracle.com/pls/apex/f?p=OTNCR:1:0" onclick="navTrack('otn','en','hnav','oracletechnologynetwork:otntutorials');">Tutorials</a></dt>
				    </dl>

				    <dl>

					    <dt><a href="/newsletters/index.html#tech" onclick="navTrack('otn','en','hnav','oracletechnologynetwork:otnnewsletters');">Newsletters</a></dt>
				    </dl>

				    <dl>

					    <dt><a href="http://events.oracle.com/search/search?start=&pageHitCount=10&group=Events&keyword=Developer" onclick="navTrack('otn','en','hnav','oracletechnologynetwork:otnoraclevents');">Events</a></dt>
				    </dl>

				</div>
				<div class="right-column">
				    <dl>

					    <dt><a href="http://blogs.oracle.com/otn/" onclick="navTrack('otn','en','hnav','oracletechnologynetwork:otnblog');">Technology Network Blog</a></dt>
				    </dl>

				    <dl>

					    <dt><a href="http://forums.oracle.com/forums/index.jspa?cat=1" onclick="navTrack('otn','en','hnav','oracletechnologynetwork:otndiscussionforums');">Discussion Forums</a></dt>
												<dd><a href="http://forums.oracle.com/forums/category.jspa?categoryID=18" onclick="navTrack('otn','en','hnav','oracletechnologynetwork:otndiscussionforums:otnforumsdatabasesql');">Database and SQL</a></dd>

												<dd><a href="http://forums.oracle.com/forums/category.jspa?categoryID=13" onclick="navTrack('otn','en','hnav','oracletechnologynetwork:otndiscussionforums:otnforumsfusionmiddleware');">Oracle Fusion Middleware</a></dd>

												<dd><a href="http://forums.oracle.com/forums/category.jspa?categoryID=70" onclick="navTrack('otn','en','hnav','oracletechnologynetwork:otndiscussionforums:otnforumsenterprisemanager');">Oracle Enterprise Manager</a></dd>

												<dd><a href="http://forums.oracle.com/forums/category.jspa?categoryID=19" onclick="navTrack('otn','en','hnav','oracletechnologynetwork:otndiscussionforums:otnforumsdeveloperstools');">Developer Tools</a></dd>

												<dd><a href="http://forums.oracle.com/forums/category.jspa?categoryID=48" onclick="navTrack('otn','en','hnav','oracletechnologynetwork:otndiscussionforums:otnforumsfeedback');">Technology Network Feedback</a></dd>

												<dd><a href="http://forums.oracle.com/forums/index.jspa?cat=1" onclick="navTrack('otn','en','hnav','oracletechnologynetwork:otndiscussionforums:otnforumsseeall');"><span class='seeAll'>See All &hellip;</span></a></dd>

				    </dl>

				    <dl>

					    <dt><a href="/technetwork/indexes/products/index.html" onclick="navTrack('otn','en','hnav','oracletechnologynetwork:otnproducttechnicalinfo');">Product Technical Info</a></dt>
												<dd><a href="/technetwork/database/enterprise-edition/overview/index.html" onclick="navTrack('otn','en','hnav','oracletechnologynetwork:otnproducttechnicalinfo:otnproducttechnicalinfodatabase');">Database</a></dd>

												<dd><a href="/technetwork/middleware/fusion-middleware/overview/index.html" onclick="navTrack('otn','en','hnav','oracletechnologynetwork:otnproducttechnicalinfo:otnproducttechnicalinfofusionmiddleware');">Oracle Fusion Middleware</a></dd>

												<dd><a href="/technetwork/oem/grid-control/overview/index.html" onclick="navTrack('otn','en','hnav','oracletechnologynetwork:otnproducttechnicalinfo:otnproducttechnicalinfoenterprisemanager');">Oracle Enterprise Manager</a></dd>

												<dd><a href="/technetwork/apps-tech/index.html" onclick="navTrack('otn','en','hnav','oracletechnologynetwork:otnproducttechnicalinfo:otnproducttechnicalinfoapplicationstechnology');">Applications Technology</a></dd>

												<dd><a href="/technetwork/indexes/products/index.html" onclick="navTrack('otn','en','hnav','oracletechnologynetwork:otnproducttechnicalinfo:otnproducttechnicalinfoseeall');"><span class='seeAll'>See All &hellip;</span></a></dd>

				    </dl>

				    <dl>

					    <dt><a href="/technetwork/topics/index.html" onclick="navTrack('otn','en','hnav','oracletechnologynetwork:technologiesandarchitecture');">Topics</a></dt>
				    </dl>

				    <dl>

					    <dt><a href="https://www.samplecode.oracle.com/" onclick="navTrack('otn','en','hnav','oracletechnologynetwork:otnsamplecode');">Sample Code</a></dt>
				    </dl>

				    <dl>

					    <dt><a href="/technetwork/techcastlive/index.html" onclick="navTrack('otn','en','hnav','oracletechnologynetwork:otnpodcastvideo');">TechCast Live</a></dt>
				    </dl>

				    <dl>

					    <dt><a href="/technetwork/oramag/index.html" onclick="navTrack('otn','en','hnav','oracletechnologynetwork:otnoraclemagazine');">Oracle Magazine</a></dt>
				    </dl>

				    <dl>

					    <dt><a href="/technetwork/community/bookstore/index.html" onclick="navTrack('otn','en','hnav','oracletechnologynetwork:otnbooks');">Books</a></dt>
				    </dl>

				    <dl>

					    <dt></dt>
				    </dl>

				</div>

			    
			    <div class="bottomleft">
				<div class="bottomcenter">
				    <div class="bottomright"> </div>
				</div>
			    </div>
		    </div>

		</li>

		<li class="special top-level last">
			<p>&nbsp;</p>
		</li>
	</ul>


			<!--SS_END_SNIPPET(fragment24,1)-->

<!--SS_BEGIN_SNIPPET(fragment29,2)-->
	
	<!--**override root for testing purposes:**-->
	<!--** Header Logo ** -->
	<!--** Header Search ** -->
	<!--** Welcome SignIn ** -->
	 
	
	<!--** Footer ** -->
	
	 
		
<!--** Header Logo ** -->
	 
	
		

	<!-- MOSAIC -->
<!-- Communities-->

<!-- User Category -->
 
<!-- User Intrest -->
<!-- Navigation starts here -->
			
					
						
																	
						
		                
				
				
				
			
		
						
			
			
				
			
		
			
				
				
						
				

				

				

				


				
		
						
						
				
				
			
			
			
			
				 
<!-- User Community SC code -->

<!-- User Category SC code -->

 
<!-- User Interest SC code -->


	
	    <div id="breadCrumb">
	    <div class="breadCrumb_Left"></div>
	    <div class="breadCrumb_Center">
	    <div style="position:relative;">
	    <span class="breadCrumb_Content">
			    <a href="/technetwork/index.html" onclick="navTrack('otn','en','breadcrumb','otnen');"><span class=red>Oracle</span> Technology Network</a>
			    <span class="rightarrow"><img src="http://www.oracleimg.com/ocom/groups/systemobject/@mktg_admin/documents/digitalasset/066625.gif" /></span>
			    <a href="/technetwork/java/index.html" onclick="navTrack('otn','en','breadcrumb','otnen_java');">Java</a>
			    <span class="rightarrow"><img src="http://www.oracleimg.com/ocom/groups/systemobject/@mktg_admin/documents/digitalasset/066625.gif" /></span>
			    <a href="/technetwork/java/javaee/index.html" onclick="navTrack('otn','en','breadcrumb','otnen_javaee');">Java EE</a>
			    <span class="rightarrow"><img src="http://www.oracleimg.com/ocom/groups/systemobject/@mktg_admin/documents/digitalasset/066625.gif" /></span>
			    <span class="active">Technologies</span>
	    </span>
	    </div>
	    </div>
	    <div class="breadCrumb_Right"></div>
	    </div>

			<!--SS_END_SNIPPET(fragment29,2)-->

      </div>

      <div id="wrapper_lnav_maincont_rcol_foot">
        <div id="Wrapper_FixedWidth_Leftnav">
          
<!--SS_BEGIN_SNIPPET(fragment25,2)-->
	
	<!--**override root for testing purposes:**-->
	<!--** Header Logo ** -->
	<!--** Header Search ** -->
	<!--** Welcome SignIn ** -->
	 
	
	<!--** Footer ** -->
	
	 
		
<!--** Header Logo ** -->
	 
	
		

	<!-- MOSAIC -->
<!-- Communities-->

<!-- User Category -->
 
<!-- User Intrest -->
<!-- Navigation starts here -->
			
					
						
																	
						
		                
				
				
				
			
		
						
			
			
				
			
		
			
				
				
						
				

				

				

				


				
		
						
						
				
				
			
			
			
			
				 
<!-- User Community SC code -->

<!-- User Category SC code -->

 
<!-- User Interest SC code -->


 <!--** retrieve input parameters: **-->
		

			
		
	<!--** retrieve the root node: **-->
	<!--rootId = ssGetFirstNodeId(siteId)-->
	<!--nodeId = rootId-->

	<!--** retrieve the nodeLevel and set it to ssNumVertLevels **-->
	<!--** retrieving the nodeLevel **-->
		        	            
	        	            
		<!--** setting the nodelevel to ssNumVertLevels **-->
                <!--** Get the section ID in custom section property **-->		
				                             
   
                	
                 
                
                <div class="topLeftNavBorder_li"><!--Spacer--></div> 
                <div class="XMLLeftNav_li" id="XMLLeftNav">

		
 
		<!--** section link: **-->    
		     
		    		   
 
											
               <ul class="level01">
				

                          
 		            	
				  <li><a class="level01_top_link_subnav" href = "/technetwork/java/javase/index.html" onclick="navTrack('otn','en','lnav','javase');"   target=_top><div>Java SE</div></a></li>
                     	 			 							
				

                          
 		            	
				  <li><a class="level01_top_link_subnav" href = "/technetwork/java/javasebusiness/index.html" onclick="navTrack('otn','en','lnav','javasebusiness');"   target=_top><div>Java SE for Business</div></a></li>
                     	 			 							
				

                          
 		            	
				  <li><a class="level01_top_link_subnav" href = "/technetwork/java/embedded/index.html" onclick="navTrack('otn','en','lnav','javaseembed');"   target=_top><div>Java Embedded</div></a></li>
                     	 			 							
				

                          
 		            	
				  <li><a class="level01_top_link_subnav" href = "/technetwork/java/javaee/index.html" onclick="navTrack('otn','en','lnav','javaee');"   target=_top><div>Java EE</div></a></li>
                     	 			 							
				

                          
 		            	
				  <li><a class="level01_top_link_subnav" href = "/technetwork/java/javame/index.html" onclick="navTrack('otn','en','lnav','javame');"   target=_top><div>Java ME</div></a></li>
                     	 			 							
				

                          
 		            	
				  <li><a class="level01_top_link_subnav" href = "/technetwork/java/javafx/index.html" onclick="navTrack('otn','en','lnav','javafx');"   target=_top><div>JavaFX</div></a></li>
                     	 			 							
				

                          
 		            	
				  <li><a class="level01_top_link_subnav" href = "/technetwork/java/javadb/index.html" onclick="navTrack('otn','en','lnav','javadb');"   target=_top><div>Java DB</div></a></li>
                     	 			 							
				

                          
 		            	
				  <li><a class="level01_top_link_subnav" href = "/technetwork/java/webtier/index.html" onclick="navTrack('otn','en','lnav','webtier');"   target=_top><div>Web Tier</div></a></li>
                     	 			 							
				

                          
 		            	
				  <li><a class="level01_top_link_subnav" href = "/technetwork/java/javacard/index.html" onclick="navTrack('otn','en','lnav','javacard');"   target=_top><div>Java Card</div></a></li>
                     	 			 							
				
		 </ul>										
 
     	        </div>
		<div class="botLeftNavBorder_li"><!--Spacer--></div>
											
	<!--** end of ExternalNavMultiV **-->


			<!--SS_END_SNIPPET(fragment25,2)-->

        </div>

        <div id="Wrapper_FixedWidth_Centercontent">
          <div class="pg0 pg0v0 pg0x1v0 pg0x1">
            
<!--SS_BEGIN_SNIPPET(fragment33,2)-->
			
	

		
				<div class="orcl6 orcl6v0">
				<div class="orcl6w0"><ul id="tabsample0">

						
						
									
						
							<li ><a href="/technetwork/java/javaee/overview/index.html" target=_top class='EXTERNALNAVTABSTOP-3' onclick="navTrack('otn','en','tab','Java:Java EE:Overview');"><span>Overview</span></a><div></div></li>
	
							<li ><a href="/technetwork/java/javaee/downloads/index.html" target=_top class='EXTERNALNAVTABSTOP-3' onclick="navTrack('otn','en','tab','Java:Java EE:Downloads');"><span>Downloads</span></a><div></div></li>
	
							<li ><a href="/technetwork/java/javaee/documentation/index.html" target=_top class='EXTERNALNAVTABSTOP-3' onclick="navTrack('otn','en','tab','Java:Java EE:Documentation');"><span>Documentation</span></a><div></div></li>
	
							<li ><a href="/technetwork/java/javaee/community/index.html" target=_top class='EXTERNALNAVTABSTOP-3' onclick="navTrack('otn','en','tab','Java:Java EE:Community');"><span>Community</span></a><div></div></li>
	
							<li class='ui-tabs-selected'><a href="/technetwork/java/javaee/tech/index.html" target=_top class='EXTERNALNAVTABSTOP-focus-3' onclick="navTrack('otn','en','tab','Java:Java EE:Technologies');"><span>Technologies</span></a><div></div></li>
	
							<li ><a href="/technetwork/java/javaee/training/index.html" target=_top class='EXTERNALNAVTABSTOP-3' onclick="navTrack('otn','en','tab','Java:Java EE:Training');"><span>Training</span></a><div></div></li>
	
				</ul></div>
				</div>
	







			<!--SS_END_SNIPPET(fragment33,2)-->
<script type="text/javascript">
window['MULTIDDOCNAMECONFIG'] = { 
show_addrowbutton: false, 
primaryurl: 'OTN-LT-3COL?MainContent=142185&RHS1=160036&RHS2=160044&RHS3=152505&RHS4=159521&RHS5=&RHS6=&RHS7=&RHS8=&RHS9=&RHS10=&RHS11=&RHS12=&RHS13=&RHS14=&RHS15=&RHS16=&RHS17=', 
rows: [ 
{ 
createnewxml_defaultmetadata_default: 'dDocTitle%3DRHS', 
browse_querytext_default: 'xWebsiteObjectType <Matches> `Data File`', 
show_createnewxmlbutton_default: true, 
show_browsebutton_default: true, 

createnewxml_defaultmetadata_override: 'dDocTitle%3DRHS', 
browse_querytext_override: 'xWebsiteObjectType <Matches> `Data File`', 
show_createnewxmlbutton_override: true, 
show_browsebutton_override: true, 

show_deletebutton: true 
}, 
{ 
createnewxml_defaultmetadata_default: 'dDocTitle%3DRHS', 
browse_querytext_default: 'xWebsiteObjectType <Matches> `Data File`', 
show_createnewxmlbutton_default: true, 
show_browsebutton_default: true, 

createnewxml_defaultmetadata_override: 'dDocTitle%3DRHS', 
browse_querytext_override: 'xWebsiteObjectType <Matches> `Data File`', 
show_createnewxmlbutton_override: true, 
show_browsebutton_override: true, 

show_deletebutton: true 
}, 
{ 
createnewxml_defaultmetadata_default: 'dDocTitle%3DRHS', 
browse_querytext_default: 'xWebsiteObjectType <Matches> `Data File`', 
show_createnewxmlbutton_default: true, 
show_browsebutton_default: true, 

createnewxml_defaultmetadata_override: 'dDocTitle%3DRHS', 
browse_querytext_override: 'xWebsiteObjectType <Matches> `Data File`', 
show_createnewxmlbutton_override: true, 
show_browsebutton_override: true, 

show_deletebutton: true 
}, 
{ 
createnewxml_defaultmetadata_default: 'dDocTitle%3DRHS', 
browse_querytext_default: 'xWebsiteObjectType <Matches> `Data File`', 
show_createnewxmlbutton_default: true, 
show_browsebutton_default: true, 

createnewxml_defaultmetadata_override: 'dDocTitle%3DRHS', 
browse_querytext_override: 'xWebsiteObjectType <Matches> `Data File`', 
show_createnewxmlbutton_override: true, 
show_browsebutton_override: true, 

show_deletebutton: true 
}, 
{ 
createnewxml_defaultmetadata_default: 'dDocTitle%3DRHS', 
browse_querytext_default: 'xWebsiteObjectType <Matches> `Data File`', 
show_createnewxmlbutton_default: true, 
show_browsebutton_default: true, 

createnewxml_defaultmetadata_override: 'dDocTitle%3DRHS', 
browse_querytext_override: 'xWebsiteObjectType <Matches> `Data File`', 
show_createnewxmlbutton_override: true, 
show_browsebutton_override: true, 

show_deletebutton: true 
}, 
{ 
createnewxml_defaultmetadata_default: 'dDocTitle%3DRHS', 
browse_querytext_default: 'xWebsiteObjectType <Matches> `Data File`', 
show_createnewxmlbutton_default: true, 
show_browsebutton_default: true, 

createnewxml_defaultmetadata_override: 'dDocTitle%3DRHS', 
browse_querytext_override: 'xWebsiteObjectType <Matches> `Data File`', 
show_createnewxmlbutton_override: true, 
show_browsebutton_override: true, 

show_deletebutton: true 
}, 
{ 
createnewxml_defaultmetadata_default: 'dDocTitle%3DRHS', 
browse_querytext_default: 'xWebsiteObjectType <Matches> `Data File`', 
show_createnewxmlbutton_default: true, 
show_browsebutton_default: true, 

createnewxml_defaultmetadata_override: 'dDocTitle%3DRHS', 
browse_querytext_override: 'xWebsiteObjectType <Matches> `Data File`', 
show_createnewxmlbutton_override: true, 
show_browsebutton_override: true, 

show_deletebutton: true 
}, 
{ 
createnewxml_defaultmetadata_default: 'dDocTitle%3DRHS', 
browse_querytext_default: 'xWebsiteObjectType <Matches> `Data File`', 
show_createnewxmlbutton_default: true, 
show_browsebutton_default: true, 

createnewxml_defaultmetadata_override: 'dDocTitle%3DRHS', 
browse_querytext_override: 'xWebsiteObjectType <Matches> `Data File`', 
show_createnewxmlbutton_override: true, 
show_browsebutton_override: true, 

show_deletebutton: true 
}, 
{ 
createnewxml_defaultmetadata_default: 'dDocTitle%3DRHS', 
browse_querytext_default: 'xWebsiteObjectType <Matches> `Data File`', 
show_createnewxmlbutton_default: true, 
show_browsebutton_default: true, 

createnewxml_defaultmetadata_override: 'dDocTitle%3DRHS', 
browse_querytext_override: 'xWebsiteObjectType <Matches> `Data File`', 
show_createnewxmlbutton_override: true, 
show_browsebutton_override: true, 

show_deletebutton: true 
}, 
{ 
createnewxml_defaultmetadata_default: 'dDocTitle%3DRHS', 
browse_querytext_default: 'xWebsiteObjectType <Matches> `Data File`', 
show_createnewxmlbutton_default: true, 
show_browsebutton_default: true, 

createnewxml_defaultmetadata_override: 'dDocTitle%3DRHS', 
browse_querytext_override: 'xWebsiteObjectType <Matches> `Data File`', 
show_createnewxmlbutton_override: true, 
show_browsebutton_override: true, 

show_deletebutton: true 
}, 
{ 
createnewxml_defaultmetadata_default: 'dDocTitle%3DRHS', 
browse_querytext_default: 'xWebsiteObjectType <Matches> `Data File`', 
show_createnewxmlbutton_default: true, 
show_browsebutton_default: true, 

createnewxml_defaultmetadata_override: 'dDocTitle%3DRHS', 
browse_querytext_override: 'xWebsiteObjectType <Matches> `Data File`', 
show_createnewxmlbutton_override: true, 
show_browsebutton_override: true, 

show_deletebutton: true 
}, 
{ 
createnewxml_defaultmetadata_default: 'dDocTitle%3DRHS', 
browse_querytext_default: 'xWebsiteObjectType <Matches> `Data File`', 
show_createnewxmlbutton_default: true, 
show_browsebutton_default: true, 

createnewxml_defaultmetadata_override: 'dDocTitle%3DRHS', 
browse_querytext_override: 'xWebsiteObjectType <Matches> `Data File`', 
show_createnewxmlbutton_override: true, 
show_browsebutton_override: true, 

show_deletebutton: true 
}, 
{ 
createnewxml_defaultmetadata_default: 'dDocTitle%3DRHS', 
browse_querytext_default: 'xWebsiteObjectType <Matches> `Data File`', 
show_createnewxmlbutton_default: true, 
show_browsebutton_default: true, 

createnewxml_defaultmetadata_override: 'dDocTitle%3DRHS', 
browse_querytext_override: 'xWebsiteObjectType <Matches> `Data File`', 
show_createnewxmlbutton_override: true, 
show_browsebutton_override: true, 

show_deletebutton: true 
}, 
{ 
createnewxml_defaultmetadata_default: 'dDocTitle%3DRHS', 
browse_querytext_default: 'xWebsiteObjectType <Matches> `Data File`', 
show_createnewxmlbutton_default: true, 
show_browsebutton_default: true, 

createnewxml_defaultmetadata_override: 'dDocTitle%3DRHS', 
browse_querytext_override: 'xWebsiteObjectType <Matches> `Data File`', 
show_createnewxmlbutton_override: true, 
show_browsebutton_override: true, 

show_deletebutton: true 
}, 
{ 
createnewxml_defaultmetadata_default: 'dDocTitle%3DRHS', 
browse_querytext_default: 'xWebsiteObjectType <Matches> `Data File`', 
show_createnewxmlbutton_default: true, 
show_browsebutton_default: true, 

createnewxml_defaultmetadata_override: 'dDocTitle%3DRHS', 
browse_querytext_override: 'xWebsiteObjectType <Matches> `Data File`', 
show_createnewxmlbutton_override: true, 
show_browsebutton_override: true, 

show_deletebutton: true 
},
{ 
createnewxml_defaultmetadata_default: 'dDocTitle%3DRHS', 
browse_querytext_default: 'xWebsiteObjectType <Matches> `Data File`', 
show_createnewxmlbutton_default: true, 
show_browsebutton_default: true, 

createnewxml_defaultmetadata_override: 'dDocTitle%3DRHS', 
browse_querytext_override: 'xWebsiteObjectType <Matches> `Data File`', 
show_createnewxmlbutton_override: true, 
show_browsebutton_override: true, 

show_deletebutton: true 
},  
{ 
createnewxml_defaultmetadata_default: 'dDocTitle%3DRHS', 
browse_querytext_default: 'xWebsiteObjectType <Matches> `Data File`', 
show_createnewxmlbutton_default: true, 
show_browsebutton_default: true, 

createnewxml_defaultmetadata_override: 'dDocTitle%3DRHS', 
browse_querytext_override: 'xWebsiteObjectType <Matches> `Data File`', 
show_createnewxmlbutton_override: true, 
show_browsebutton_override: true, 

show_deletebutton: true 
}                    
] 
}; 
</script>
<style>
  .sidebox h4 a:link {_width:178px;}
  .sidebox h4 a:visited{_width:178px;}
  .sidebox h4 a:hover {_width:178px;}
</style>
	<div class="orcl6w1">
	<div class="orcl6x0"></div>
</div>
<div class="orcl6w2">
	<div class="orcl6w3">
		
						<h1>Java EE 6 Technologies</h1>
<!-- content goes here -->
<table width="100%" cellspacing="10" cellpadding="5" border="0">
    <tbody>
        <tr valign="top" align="center" bgcolor="#e0e0e0">
            <td width="20%">
            <h5><br />
            <a title="At a Glance" href="/technetwork/java/javaee/tech/index-jsp-142185.html"><strong>At a Glance</strong></a>&nbsp;</h5>
            </td>
            <td width="15%">
            <h5><br />
            <a title="Java EE 5" href="/technetwork/java/javaee/tech/javaee5-jsp-135162.html"><strong>Java EE 5</strong></a><br />
            &nbsp;</h5>
            </td>
            <td width="15%">
            <h5><br />
            <a title="Web Services" href="/technetwork/java/javaee/tech/webservices-139501.html"><strong>Web Services</strong></a><br />
            &nbsp;</h5>
            </td>
            <td width="15%">
            <h5><br />
            <a title="Web App" href="/technetwork/java/javaee/tech/webapps-138511.html"><strong>Web App</strong></a><br />
            &nbsp;</h5>
            </td>
            <td width="20%">
            <h5><br />
            <a title="Enterprise App" href="/technetwork/java/javaee/tech/entapps-138775.html"><strong>Enterprise App</strong></a><br />
            &nbsp;</h5>
            </td>
            <td width="15%">
            <h5><br />
            <a title="Management" href="/technetwork/java/javaee/tech/management-139662.html"><strong>Management</strong></a><br />
            &nbsp;</h5>
            </td>
        </tr>
    </tbody>
</table>
<div class="cornerBR"><!-- END D7 COMPONENT V.4 -->
<div style="padding:15px;">
<p class="intro">Learn more about the technologies that comprise the Java EE 6 platform using the specifications, and then apply them with the                           <a href="/technetwork/java/javaee/downloads/index.html">Java EE 6 SDK</a>.                         <br />
<br />
Specification downloads are the final releases. Please check the individual JSR pages for download updates such as maintenance releases.</p>
<!-- BEGIN PC2 COMPONENT V.0 -->
<div class="pc2">
<table border="0" cellpadding="0" cellspacing="0" width="100%">
    <tbody>
        <tr class="titlebar">
            <th colspan="3">
            <div>Java EE 6 Technologies</div>
            </th>
        </tr>
        <tr class="subtitlebar">
            <th class="dcell">&nbsp;&nbsp;Technologies</th>
            <th class="dcell">JSR</th>
            <th class="dcell">Download</th>
        </tr>
        <tr>
            <td class="dcell" width="65%"><a target="_blank" href="http://jcp.org/en/jsr/detail?id=316">                                <strong>Java&nbsp;Platform,&nbsp;Enterprise&nbsp;Edition&nbsp;6&nbsp;(Java&nbsp;EE&nbsp;6)</strong>                               </a>                               <br />
            (includes Managed Beans 1.0)</td>
            <td class="dcell" width="15%"><a target="_blank" href="http://jcp.org/en/jsr/detail?id=316">JSR&nbsp;316</a></td>
            <td class="dcell" width="20%"><a target="_blank" href="http://jcp.org/aboutJava/communityprocess/pr/jsr316/index.html">Download&nbsp;spec</a></td>
        </tr>
        <tr>
            <td class="line" colspan="3"><hr />
            </td>
        </tr>
        <tr>
            <td class="intro" colspan="3"><strong>Web Services Technologies</strong>&nbsp;&nbsp;&nbsp;                               <span class="rightarrowblue">&raquo;</span>                                 <a href="/technetwork/java/javaee/tech/webservices-139501.html">Read more</a></td>
        </tr>
        <tr>
            <td class="line" colspan="3"><hr />
            </td>
        </tr>
        <tr>
            <td class="dcell" width="70%"><a target="_blank" href="http://jcp.org/en/jsr/detail?id=311">                                <strong>Java API for RESTful Web Services (JAX-RS) 1.1</strong>                               </a></td>
            <td class="dcell" width="10%"><a target="_blank" href="http://jcp.org/en/jsr/detail?id=311">JSR 311</a></td>
            <td class="dcell" width="20%"><a target="_blank" href="http://jcp.org/aboutJava/communityprocess/final/jsr311/index.html">Download spec</a></td>
        </tr>
        <tr>
            <td class="line" colspan="3"><hr />
            </td>
        </tr>
        <tr>
            <td class="dcell" width="70%"><a target="_blank" href="http://jcp.org/en/jsr/detail?id=109">                                <strong>Implementing&nbsp;Enterprise&nbsp;Web&nbsp;Services 1.3</strong>                               </a></td>
            <td class="dcell" width="10%"><a target="_blank" href="http://jcp.org/en/jsr/detail?id=109">JSR 109</a></td>
            <td class="dcell" width="20%"><a target="_blank" href="http://jcp.org/aboutJava/communityprocess/final/jsr109/index.html">Download spec</a></td>
        </tr>
        <tr>
            <td class="line" colspan="3"><hr />
            </td>
        </tr>
        <tr>
            <td class="dcell" width="70%"><a target="_blank" href="https://jax-ws.dev.java.net/">                                <strong>Java API for XML-Based Web Services (JAX-WS) 2.2</strong>                               </a></td>
            <td class="dcell" width="10%"><a target="_blank" href="http://jcp.org/en/jsr/detail?id=224">JSR 224</a></td>
            <td class="dcell" width="20%"><a target="_blank" href="http://jcp.org/aboutJava/communityprocess/final/jsr224/index.html">Download spec</a></td>
        </tr>
        <tr>
            <td class="line" colspan="3"><hr />
            </td>
        </tr>
        <tr>
            <td class="dcell" width="70%"><a target="_blank" href="https://jaxb.dev.java.net/">                                <strong>Java&nbsp;Architecture&nbsp;for&nbsp;XML&nbsp;Binding&nbsp;(JAXB)&nbsp;2.2</strong>                               </a></td>
            <td class="dcell" width="10%"><a target="_blank" href="http://jcp.org/en/jsr/detail?id=222">JSR 222</a></td>
            <td class="dcell" width="20%"><a target="_blank" href="http://jcp.org/aboutJava/communityprocess/final/jsr222/index.html">Download spec</a></td>
        </tr>
        <tr>
            <td class="line" colspan="3"><hr />
            </td>
        </tr>
        <tr>
            <td class="dcell" width="70%"><a target="_blank" href="http://jcp.org/en/jsr/detail?id=181">                                <strong>Web Services Metadata for the Java Platform</strong>                               </a></td>
            <td class="dcell" width="10%"><a target="_blank" href="http://jcp.org/en/jsr/detail?id=181">JSR 181</a></td>
            <td class="dcell" width="20%"><a target="_blank" href="http://jcp.org/aboutJava/communityprocess/final/jsr181/index.html">Download spec</a></td>
        </tr>
        <tr>
            <td class="line" colspan="3"><hr />
            </td>
        </tr>
        <tr>
            <td class="dcell" width="70%"><a target="_blank" href="https://jax-rpc.dev.java.net/">                                <strong>Java&nbsp;API&nbsp;for&nbsp;XML-Based&nbsp;RPC&nbsp;(JAX-RPC)&nbsp;1.1</strong>                               </a></td>
            <td class="dcell" width="10%"><a target="_blank" href="http://jcp.org/en/jsr/detail?id=101">JSR 101</a></td>
            <td class="dcell" width="20%"><a target="_blank" href="http://jcp.org/aboutJava/communityprocess/final/jsr101/index2.html">Download spec</a></td>
        </tr>
        <tr>
            <td class="line" colspan="3"><hr />
            </td>
        </tr>
        <tr>
            <td class="dcell" width="70%"><a target="_blank" href="http://jcp.org/en/jsr/detail?id=67">                                <strong>Java APIs for XML Messaging 1.3</strong>                               </a></td>
            <td class="dcell" width="10%"><a target="_blank" href="http://jcp.org/en/jsr/detail?id=67">JSR 67</a></td>
            <td class="dcell" width="20%"><a target="_blank" href="http://jcp.org/aboutJava/communityprocess/final/jsr067/index.html">Download spec</a></td>
        </tr>
        <tr>
            <td class="line" colspan="3"><hr />
            </td>
        </tr>
        <tr>
            <td class="dcell" width="70%"><a target="_blank" href="http://jcp.org/en/jsr/detail?id=93">                                <strong>Java API for XML Registries (JAXR) 1.0</strong>                               </a></td>
            <td class="dcell" width="10%"><a target="_blank" href="http://jcp.org/en/jsr/detail?id=93">JSR 93</a></td>
            <td class="dcell" width="20%"><a target="_blank" href="http://jcp.org/aboutJava/communityprocess/final/jsr093/index.html">Download spec</a></td>
        </tr>
        <tr>
            <td class="line" colspan="3"><hr />
            </td>
        </tr>
        <tr>
            <td class="intro" colspan="3"><strong>Web Application Technologies</strong>&nbsp;&nbsp;&nbsp;                               <span class="rightarrowblue">&raquo;</span>                                 <a href="/technetwork/java/javaee/tech/webapps-138511.html">Read more</a></td>
        </tr>
        <tr>
            <td class="line" colspan="3"><hr />
            </td>
        </tr>
        <tr>
            <td class="dcell" width="70%"><a href="/technetwork/java/index-jsp-135475.html">                                <strong>Java Servlet 3.0</strong>                               </a></td>
            <td class="dcell" width="10%"><a target="_blank" href="http://jcp.org/en/jsr/detail?id=315">JSR 315</a></td>
            <td class="dcell" width="20%"><a target="_blank" href="http://jcp.org/aboutJava/communityprocess/pfd/jsr315/index.html">Download spec</a></td>
        </tr>
        <tr>
            <td class="line" colspan="3"><hr />
            </td>
        </tr>
        <tr>
            <td class="dcell" width="70%"><a href="/technetwork/java/javaee/javaserverfaces-139869.html">                                <strong>JavaServer Faces 2.0</strong>                               </a></td>
            <td class="dcell" width="10%"><a target="_blank" href="http://jcp.org/en/jsr/detail?id=314">JSR 314</a></td>
            <td class="dcell" width="20%"><a target="_blank" href="http://jcp.org/aboutJava/communityprocess/pfd/jsr314/index.html">Download spec</a></td>
        </tr>
        <tr>
            <td class="line" colspan="3"><hr />
            </td>
        </tr>
        <tr>
            <td class="dcell" width="70%"><a href="/technetwork/java/jsp-138432.html">                                <strong>JavaServer Pages 2.2/Expression Language 2.2</strong>                               </a></td>
            <td class="dcell" width="10%"><a target="_blank" href="http://jcp.org/en/jsr/detail?id=245">JSR 245</a></td>
            <td class="dcell" width="20%"><a target="_blank" href="http://jcp.org/aboutJava/communityprocess/final/jsr245/index.html">Download spec</a></td>
        </tr>
        <tr>
            <td class="line" colspan="3"><hr />
            </td>
        </tr>
        <tr>
            <td class="dcell" width="70%"><a href="/technetwork/java/jstl-137486.html">                                <strong>Standard Tag Library for JavaServer Pages (JSTL) 1.2</strong>                               </a></td>
            <td class="dcell" width="10%"><a target="_blank" href="http://jcp.org/en/jsr/detail?id=52">JSR 52</a></td>
            <td class="dcell" width="20%"><a target="_blank" href="http://jcp.org/aboutJava/communityprocess/final/jsr052/index.html">Download spec</a></td>
        </tr>
        <tr>
            <td class="line" colspan="3"><hr />
            </td>
        </tr>
        <tr>
            <td class="dcell" width="70%"><a target="_blank" href="http://jcp.org/en/jsr/detail?id=45">                                <strong>Debugging Support for Other Languages 1.0</strong>                               </a></td>
            <td class="dcell" width="10%"><a target="_blank" href="http://jcp.org/en/jsr/detail?id=45">JSR 45</a></td>
            <td class="dcell" width="20%"><a target="_blank" href="http://jcp.org/aboutJava/communityprocess/final/jsr045/index.html">Download spec</a></td>
        </tr>
        <tr>
            <td class="line" colspan="3"><hr />
            </td>
        </tr>
        <tr>
            <td class="intro" colspan="3"><strong>Enterprise Application Technologies</strong>&nbsp;&nbsp;&nbsp;                               <span class="rightarrowblue">&raquo;</span>                                 <a href="/technetwork/java/javaee/tech/entapps-138775.html">Read more</a></td>
        </tr>
        <tr>
            <td class="line" colspan="3"><hr />
            </td>
        </tr>
        <tr>
            <td class="dcell" width="70%"><a target="_blank" href="http://jcp.org/en/jsr/detail?id=299">                                <strong>Contexts and Dependency Injection for Java (Web Beans 1.0)</strong>                               </a></td>
            <td class="dcell" width="10%"><a target="_blank" href="http://jcp.org/en/jsr/detail?id=299">JSR 299</a></td>
            <td class="dcell" width="20%"><a target="_blank" href="http://jcp.org/aboutJava/communityprocess/pr/jsr299/index.html">Download spec</a></td>
        </tr>
        <tr>
            <td class="line" colspan="3"><hr />
            </td>
        </tr>
        <tr>
            <td class="dcell" width="70%"><a target="_blank" href="http://jcp.org/en/jsr/summary?id=330">                                <strong>Dependency Injection for Java 1.0</strong>                               </a></td>
            <td class="dcell" width="10%"><a target="_blank" href="http://jcp.org/en/jsr/summary?id=330">JSR 330</a></td>
            <td class="dcell" width="20%"><a target="_blank" href="http://jcp.org/aboutJava/communityprocess/final/jsr330/index.html">Download spec</a></td>
        </tr>
        <tr>
            <td class="line" colspan="3"><hr />
            </td>
        </tr>
        <tr>
            <td class="dcell" width="70%"><a target="_blank" href="http://jcp.org/en/jsr/detail?id=303">                                <strong>Bean Validation 1.0</strong>                               </a></td>
            <td class="dcell" width="10%"><a target="_blank" href="http://jcp.org/en/jsr/detail?id=303">JSR 303</a></td>
            <td class="dcell" width="20%"><a target="_blank" href="http://jcp.org/aboutJava/communityprocess/pfd/jsr303/index.html">Download spec</a></td>
        </tr>
        <tr>
            <td class="line" colspan="3"><hr />
            </td>
        </tr>
        <tr>
            <td class="dcell" width="70%"><a href="/technetwork/java/ejb-141389.html">                                <strong>Enterprise JavaBeans 3.1</strong>                               </a>                               <br />
            (includes Interceptors 1.1)</td>
            <td class="dcell" width="10%"><a target="_blank" href="http://jcp.org/en/jsr/detail?id=318">JSR 318</a></td>
            <td class="dcell" width="20%"><a target="_blank" href="http://jcp.org/aboutJava/communityprocess/pfd/jsr318/index.html">Download spec</a></td>
        </tr>
        <tr>
            <td class="line" colspan="3"><hr />
            </td>
        </tr>
        <tr>
            <td class="dcell" width="70%"><a target="_blank" href="http://jcp.org/en/jsr/detail?id=322">                                <strong>Java EE Connector Architecture 1.6</strong>                               </a></td>
            <td class="dcell" width="10%"><a target="_blank" href="http://jcp.org/en/jsr/detail?id=322">JSR 322</a></td>
            <td class="dcell" width="20%"><a target="_blank" href="http://jcp.org/aboutJava/communityprocess/pfd/jsr322/index.html">Download spec</a></td>
        </tr>
        <tr>
            <td class="line" colspan="3"><hr />
            </td>
        </tr>
        <tr>
            <td class="dcell" width="70%"><a target="_blank" href="http://www.jcp.org/en/jsr/detail?id=317">                                <strong>Java Persistence 2.0</strong>                               </a></td>
            <td class="dcell" width="10%"><a target="_blank" href="http://www.jcp.org/en/jsr/detail?id=317">JSR 317</a></td>
            <td class="dcell" width="20%"><a target="_blank" href="http://jcp.org/aboutJava/communityprocess/pfd/jsr317/index.html">Download spec</a></td>
        </tr>
        <tr>
            <td class="line" colspan="3"><hr />
            </td>
        </tr>
        <tr>
            <td class="dcell" width="70%"><a target="_blank" href="http://jcp.org/en/jsr/detail?id=250">                                <strong>Common&nbsp;Annotations&nbsp;for&nbsp;the&nbsp;Java&nbsp;Platform 1.1</strong>                               </a></td>
            <td class="dcell" width="10%"><a target="_blank" href="http://jcp.org/en/jsr/detail?id=250">JSR 250</a></td>
            <td class="dcell" width="20%"><a target="_blank" href="http://jcp.org/aboutJava/communityprocess/final/jsr250/index.html">Download spec</a></td>
        </tr>
        <tr>
            <td class="line" colspan="3"><hr />
            </td>
        </tr>
        <tr>
            <td class="dcell" width="70%"><a href="/technetwork/java/jms-136181.html">                                <strong>Java Message Service API 1.1</strong>                               </a></td>
            <td class="dcell" width="10%"><a target="_blank" href="http://www.jcp.org/en/jsr/detail?id=914">JSR 914</a></td>
            <td class="dcell" width="20%"><a target="_blank" href="http://jcp.org/aboutJava/communityprocess/final/jsr914/index.html">Download spec</a></td>
        </tr>
        <tr>
            <td class="line" colspan="3"><hr />
            </td>
        </tr>
        <tr>
            <td class="dcell" width="70%"><a href="/technetwork/java/javaee/tech/jta-138684.html">                                <strong>Java Transaction API (JTA) 1.1</strong>                               </a></td>
            <td class="dcell" width="10%"><a target="_blank" href="http://jcp.org/en/jsr/detail?id=907">JSR 907</a></td>
            <td class="dcell" width="20%"><a target="_blank" href="/technetwork/java/javaee/tech/jta-138684.html">Download spec</a></td>
        </tr>
        <tr>
            <td class="line" colspan="3"><hr />
            </td>
        </tr>
        <tr>
            <td class="dcell" width="70%"><a href="/technetwork/java/javamail-138606.html">                                <strong>JavaMail 1.4</strong>                               </a></td>
            <td class="dcell" width="10%"><a target="_blank" href="http://jcp.org/en/jsr/detail?id=919">JSR 919</a></td>
            <td class="dcell" width="20%"><a href="/technetwork/java/index-138643.html">Download spec</a></td>
        </tr>
        <tr>
            <td class="line" colspan="3"><hr />
            </td>
        </tr>
        <tr>
            <td class="intro" colspan="3"><strong>Management and Security Technologies</strong>&nbsp;&nbsp;&nbsp;                               <span class="rightarrowblue">&raquo;</span>                                 <a href="/technetwork/java/javaee/tech/management-139662.html">Read more</a></td>
        </tr>
        <tr>
            <td class="line" colspan="3"><hr />
            </td>
        </tr>
        <tr>
            <td class="dcell" width="70%"><a target="_blank" href="http://jcp.org/en/jsr/detail?id=196">                                <strong>Java Authentication Service Provider Interface for Containers</strong>                               </a></td>
            <td class="dcell" width="10%"><a target="_blank" href="http://jcp.org/en/jsr/detail?id=196">JSR 196</a></td>
            <td class="dcell" width="20%"><a target="_blank" href="http://jcp.org/aboutJava/communityprocess/final/jsr196/index.html">Download spec</a></td>
        </tr>
        <tr>
            <td class="line" colspan="3"><hr />
            </td>
        </tr>
        <tr>
            <td class="dcell" width="70%"><a target="_blank" href="http://jcp.org/en/jsr/detail?id=115">                                <strong>Java Authorization Contract for Containers 1.3</strong>                               </a></td>
            <td class="dcell" width="10%"><a target="_blank" href="http://jcp.org/en/jsr/detail?id=115">JSR 115</a></td>
            <td class="dcell" width="20%"><a target="_blank" href="http://jcp.org/aboutJava/communityprocess/final/jsr115/index.html">Download spec</a></td>
        </tr>
        <tr>
            <td class="line" colspan="3"><hr />
            </td>
        </tr>
        <tr>
            <td class="dcell" width="70%"><a target="_blank" href="http://jcp.org/en/jsr/detail?id=88">                                <strong>Java EE Application Deployment 1.2</strong>                               </a></td>
            <td class="dcell" width="10%"><a target="_blank" href="http://jcp.org/en/jsr/detail?id=88">JSR 88</a></td>
            <td class="dcell" width="20%"><a target="_blank" href="http://jcp.org/aboutJava/communityprocess/final/jsr088/index.html">Download spec</a></td>
        </tr>
        <tr>
            <td class="line" colspan="3"><hr />
            </td>
        </tr>
        <tr>
            <td class="dcell" width="70%"><a target="_blank" href="http://jcp.org/en/jsr/detail?id=77">                                <strong>J2EE Management 1.1</strong>                               </a></td>
            <td class="dcell" width="10%"><a target="_blank" href="http://jcp.org/en/jsr/detail?id=77">JSR 77</a></td>
            <td class="dcell" width="20%"><a target="_blank" href="http://jcp.org/aboutJava/communityprocess/final/jsr077/index.html">Download spec</a></td>
        </tr>
        <tr>
            <td class="line" colspan="3"><hr />
            </td>
        </tr>
        <tr>
            <td class="intro" colspan="3"><strong>Java EE-related Specs in Java SE</strong></td>
        </tr>
        <tr>
            <td class="line" colspan="3"><hr />
            </td>
        </tr>
        <tr>
            <td class="dcell" width="70%"><a target="_blank" href="https://jaxp.dev.java.net/">                                <strong>Java API for XML Processing (JAXP) 1.3</strong>                               </a></td>
            <td class="dcell" width="10%"><a target="_blank" href="http://jcp.org/en/jsr/detail?id=206">JSR 206</a></td>
            <td class="dcell" width="20%"><a target="_blank" href="http://jcp.org/aboutJava/communityprocess/final/jsr206/index.html">Download spec</a></td>
        </tr>
        <tr>
            <td class="line" colspan="3"><hr />
            </td>
        </tr>
        <tr>
            <td class="dcell" width="70%"><a target="_blank" href="http://jcp.org/en/jsr/detail?id=221">                                <strong>Java Database Connectivity 4.0</strong>                               </a></td>
            <td class="dcell" width="10%"><a target="_blank" href="http://jcp.org/en/jsr/detail?id=221">JSR 221</a></td>
            <td class="dcell" width="20%"><a target="_blank" href="http://jcp.org/aboutJava/communityprocess/final/jsr221/index.html">Download spec</a></td>
        </tr>
        <tr>
            <td class="line" colspan="3"><hr />
            </td>
        </tr>
        <tr>
            <td class="dcell" width="70%"><a target="_blank" href="/technetwork/java/javase/tech/javamanagement-140525.html">                                <strong>Java Management Extensions (JMX) 2.0</strong>                               </a></td>
            <td class="dcell" width="10%"><a target="_blank" href="http://jcp.org/en/jsr/detail?id=255">JSR 255</a></td>
            <td class="dcell" width="20%"><a target="_blank" href="http://jcp.org/aboutJava/communityprocess/edr/jsr255/index.html">Download spec</a></td>
        </tr>
        <tr>
            <td class="line" colspan="3"><hr />
            </td>
        </tr>
        <tr>
            <td class="dcell" width="70%"><a href="/technetwork/java/javase/jaf-135115.html">                                <strong>JavaBeans Activation Framework (JAF) 1.1</strong>                               </a></td>
            <td class="dcell" width="10%"><a target="_blank" href="http://jcp.org/en/jsr/detail?id=925">JSR 925</a></td>
            <td class="dcell" width="20%"><a href="/technetwork/java/javase/downloads/index-135046.html">Download spec</a></td>
        </tr>
        <tr>
            <td class="line" colspan="3"><hr />
            </td>
        </tr>
        <tr>
            <td class="dcell" width="70%"><a target="_blank" href="http://jcp.org/en/jsr/detail?id=173">                                <strong>Streaming API for XML (StAX) 1.0</strong>                               </a></td>
            <td class="dcell" width="10%"><a target="_blank" href="http://jcp.org/en/jsr/detail?id=173">JSR 173</a></td>
            <td class="dcell" width="20%"><a target="_blank" href="http://jcp.org/aboutJava/communityprocess/final/jsr173/index.html">Download spec</a></td>
        </tr>
        <tr>
            <td class="line" colspan="3"><hr />
            </td>
        </tr>
    </tbody>
</table>
<!-- END MAIN CONTENT -->                           <!-- BEGIN D7 COMPONENT V.5 --></div>
</div>
</div>
					
	</div>
</div>
<div class="orcl6w5"><div class="orcl6x0"></div><div class="orcl6x1"></div></div>
	<div class="orcl6w6">
		<div class="orcl6x0"></div>
		<div class="orcl6x1"></div>
	
</div>

   
  

  </div>
<div id="Wrapper_FixedWidth_Rightnav">
<div style="background-color:#FFFFFF;">
    
                                      
       <style type="text/css">
body {font-family:Arial, Helvetica, sans-serif}
#downRSS {padding:0;position:absolute;top:3px;right:10px;}
#downWrapper {padding:0 0 0px 0;background-color:#ffffff;}
#downMain {padding:5px 0 0 0; margin: 0; font-size:12px; }
#downMain .downLoad {background-image:url(http://www.oracleimg.com/ocom/groups/public/@otn/documents/digitalasset/115899.gif); background-repeat:no-repeat; background-position:top left; padding:0 0 10px 16px; margin:0 0 0 5px;}
#downMain a:link {color:#000;text-decoration:underline;} 
#downMain a:visited {color:#999;text-decoration:underline;}
#downMain a:hover {color:#ff0000;text-decoration:underline;}
</style>
<table width="100%" cellspacing="0" cellpadding="0" border="0" bgcolor="#dddddd">
    <tbody>
        <tr>
            <td><img width="10" height="20" alt="Left Curve" src="/ocom/groups/public/@otn/documents/digitalasset/121830.gif" /></td>
            <td align="center">
            <div align="center"><span class="boldbodycopy">Java SDKs and Tools</span></div>
            </td>
            <td align="right"><img width="10" height="20" alt="Right Curve" src="/ocom/groups/public/@otn/documents/digitalasset/104150.gif" /></td>
        </tr>
        <tr>
            <td colspan="3">
            <div id="downWrapper">
            <div id="downMain">
            <div class="downLoad"><a target="" href="/technetwork/java/javase/downloads/index.html">Java SE</a></div>
            <div class="downLoad"><a target="" href="/technetwork/java/javaee/downloads/index.html">Java EE and Glassfish</a></div>
            <div class="downLoad"><a target="" href="/technetwork/java/javame/downloads/index.html">Java ME</a></div>
<div class="downLoad"><a target="" href="/technetwork/java/javafx/downloads/index.html">JavaFX</a></div>
            <div class="downLoad"><a target="" href="/technetwork/java/javacard/downloads/index.html">Java Card</a></div>
<div class="downLoad"><a target="" href="http://netbeans.org/downloads/index.html">NetBeans IDE</a></div>
            
            </div>
            </div>
            </td>
        </tr>
    </tbody>
</table>

                   
                                      
       <style type="text/css">
body {font-family:Arial, Helvetica, sans-serif}
#downRSS {padding:0;position:absolute;top:3px;right:10px;}
#downWrapper {padding:0 0 0px 0;background-color:#ffffff;}
#downMain {padding:5px 0 0 0; margin: 0; font-size:12px; }
#downMain .downLoad {background-image:url(http://www.oracleimg.com/ocom/groups/public/@otn/documents/digitalasset/115899.gif); background-repeat:no-repeat; background-position:top left; padding:0 0 10px 16px; margin:0 0 0 5px;}
#downMain a:link {color:#000;text-decoration:underline;} 
#downMain a:visited {color:#999;text-decoration:underline;}
#downMain a:hover {color:#ff0000;text-decoration:underline;}
</style> <table width="100%" cellspacing="0" cellpadding="0" border="0" bgcolor="#dddddd">     <tbody>         <tr>             <td><img width="10" height="20" alt="Left Curve" src="/ocom/groups/public/@otn/documents/digitalasset/121830.gif" /></td>             <td align="center"><div align="center"><span class="boldbodycopy">Java Resources</span></div></td>             <td align="right"><img width="10" height="20" alt="Right Curve" src="/ocom/groups/public/@otn/documents/digitalasset/104150.gif" /></td>         </tr>         <tr>             <td colspan="3"><div id="downWrapper"><div id="downMain"><div class="downLoad"><a target="" href="/technetwork/topics/newtojava/overview/index.html">New to Java?</a></div>             <div class="downLoad"><a target="" href="/technetwork/java/api-141528.html">APIs</a></div>             <div class="downLoad"><a target="" href="http://wikis.sun.com/display/code/Home">Code Samples &amp; Apps</a></div>             <div class="downLoad"><a target="" href="http://education.oracle.com/pls/web_prod-plq-dad/db_pages.getpage?page_id=315&amp;p_org_id=1001&amp;lang=US">Developer Training</a></div>             <div class="downLoad"><a target="" href="../documentation/index.html">Documentation</a></div>             <div class="downLoad"><a target="" href="/technetwork/java/blueprints-141945.html">Java BluePrints</a></div>             <div class="downLoad"><a target="" href="http://www.java.com">Java.com</a></div>             <div class="downLoad"><a target="" href="http://www.java.net">Java.net</a></div>             <div class="downLoad"><a target="" href="http://www.oracle.com/us/corporate/citizenship/community/038108.htm?ssSourceSiteId=otnen">Student Developers</a></div>             <div class="downLoad"><a target="" href="/technetwork/java/index-jsp-135888.html">Tutorials</a></div></div></div></td>         </tr>     </tbody> </table>

                   
                                      
       <a href="http://www.oracle.com/go/?&amp;Src=6896290&amp;Act=114&amp;pcode=WWMK09102215MPP001"><img border="0" alt="One City, One Week, Three Conferences. Oracle OpenWorld, JavaOne, and Oracle Develop" src="http://www.oracleimg.com/ocom/groups/public/@ocom/documents/digitalasset/164136.gif" /></a> <p>&nbsp;</p>

                   
                                      
       

                   
</div>
</div>

          </div>

          <div id="Wrapper_FixedWidth_Footer">
            
<!--SS_BEGIN_SNIPPET(fragment22,ocom translation)-->				<!--** retrieve cache lifespan parameter: **-->

	
	<!--**override root for testing purposes:**-->
	<!--** Header Logo ** -->
	<!--** Header Search ** -->
	<!--** Welcome SignIn ** -->
	 
	
	<!--** Footer ** -->
	
	 
		
<!--** Header Logo ** -->
	 
	
		

	<!-- MOSAIC -->
<!-- Communities-->

<!-- User Category -->
 
<!-- User Intrest -->
<!-- Navigation starts here -->
			
					
						
																	
						
		                
				
				
				
			
		
						
			
			
				
			
		
			
				
				
						
				

				

				

				


				
		
						
						
				
				
			
			
			
			
				 
<!-- User Community SC code -->

<!-- User Category SC code -->

 
<!-- User Interest SC code -->

	<div class='greyBarBottom'><!--footer--></div><div class='infoCompany'><a onclick="navTrack('otn','en','footer','software.hardware.complete');" href='http://www.oracle.com/us/corporate/index.html'><img src='http://www.oracleimg.com/ocom/groups/systemobject/@mktg_admin/@ocom_admin/documents/digitalasset/ora_info_company.gif' border='0'  alt='software.hardware.complete'/></a></div><div class='footerContent' style{float:right}><a href='http://www.oracle.com/corporate/index.html' onclick="navTrack('otn','en','footer','about oracle');" class='footerLinks'>About 
	        Oracle</a> | <a onclick="navTrack('otn','en','footer','oracle and sun');" href='http://www.oracle.com/sun/index.html' class='footerLinks'>Oracle and Sun</a> | <a href='http://www.oracle.com/rss/index.html' onclick="navTrack('otn','en','footer','rss');"> <img src='http://www.oracleimg.com/ocom/groups/systemobject/@mktg_admin/@ocom_admin/documents/digitalasset/feed-icon-14x14.png' alt='Oracle RSS Feeds' style='margin-bottom: 1px;' align='absmiddle' border='0' height='14' width='14'></a> | <a href='http://www.oracle.com/subscribe/index.html' onclick="navTrack('otn','en','footer','subscribe');" class='footerLinks'>Subscribe</a>
	        | <a href='http://www.oracle.com/corporate/employment/index.html' onclick="navTrack('otn','en','footer','careers');" class='footerLinks'>Careers</a> | <a href='http://www.oracle.com/corporate/contact/index.html' onclick="navTrack('otn','en','footer','contact us');" class='footerLinks'>Contact 
	        Us</a> | <a href='http://www.oracle.com/sitemaps/sitemaps.html' onclick="navTrack('otn','en','footer','site maps');" class='footerLinks'>Site Maps</a> | <a href='http://www.oracle.com/html/copyright.html' onclick="navTrack('otn','en','footer','legal notices');" class='footerLinks'>Legal 
        Notices</a> | <a href='http://www.oracle.com/html/terms.html' onclick="navTrack('otn','en','footer','terms of use');" class='footerLinks'>Terms of Use</a> | <a href='http://www.oracle.com/html/privacy.html' onclick="navTrack('otn','en','footer','privacy rights');" class='footerLinks'>Your Privacy Rights</a></div>

			<!--SS_END_SNIPPET(fragment22,ocom translation)-->

          </div>
        </div>

        <div id="light" class="sitefinder_content">
          <!--spacer-->
        </div>

        <div id="fade" class="lightbox_overlay">
          <!--spacer-->
        </div>
<!--SS_BEGIN_SNIPPET(fragment36,1)-->		        	            
	        	            
	        	            
<!-- No SC code for Education site -->	
	
<!-- Start SiteCatalyst code   -->
<script language="JavaScript" src="/ocom/groups/systemobject/@mktg_admin/documents/systemobject/s_code_otn.js"></script>
<script language="JavaScript" src="/ocom/groups/systemobject/@mktg_admin/documents/systemobject/s_code.js"></script>
 
<!-- ********** DO NOT ALTER ANYTHING BELOW THIS LINE ! *********** -->
<!--  Below code will send the info to Omniture server -->
<script language="javascript">var s_code=s.t();if(s_code)document.write(s_code)</script>
<!-- End SiteCatalyst code -->
			<!--SS_END_SNIPPET(fragment36,1)-->

      </div>
    </div>
  </div>
<!--SS_BEGIN_SNIPPET(fragment35,universal-webcache-integration)-->
				
			<!--SS_END_SNIPPET(fragment35,universal-webcache-integration)-->

</body>
</html>
