<#include "/java_copyright.include">
<#assign className = table.className>   
<#assign classNameLower = className?uncap_first> 
<#assign classNameLowerCase = table.classNameLowerCase>   
package ${basepackage}.web.controller;

import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import ${basepackage}.manager.${className}Manager;
import ${basepackage}.model.${className};
import ${basepackage}.vo.${className}VO;
import com.htffund.etrade.sdk.base.json.JsonResult;
import com.htffund.etrade.sdk.base.paginator.domain.PageBounds;
import com.htffund.etrade.sdk.base.vo.PageVO;

<#include "/java_classdoc.include">


@Controller
@RequestMapping(value = "/${className}")
public class ${className}Controller {
	/**logger*/
	static final Logger log = LogManager.getLogger(${className}Controller.class.getName());
	
	@Autowired
	private ${className}Manager ${classNameLower}Manager;
	
	/**列出所有记录
	 * @param model 数据对象
	 * @return
	 */
	@RequestMapping(value = "listAll.htm")
	public String list(Model model){
		log.debug("execute  ${className}Controller listAll");
		model.addAttribute("${classNameLower}List",${classNameLower}Manager.listAll());
		return "${classNameLowerCase}/listall";
	}
	/**分页查询
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "list.htm")
	public String pageList(${className}VO ${classNameLower}VO,PageVO pageVO, Model model){
		log.debug("execute  ${className}Controller list");
		PageBounds pageBounds=pageVO.toPageBounds();
		List<${className}> pageList=${classNameLower}Manager.pageList(${classNameLower}VO,pageBounds);
		//分页查询结果列表		
		model.addAttribute("pageList",pageList);
		//回传查询参数
		model.addAttribute("params",${classNameLower}VO);
		return "${classNameLowerCase}/list";
	}
	
	/**根据ID查询记录信息
	 <#list table.compositeIdColumns as column> 
	 * @param ${column.columnNameLower} ${column.columnAlias} 
	 </#list>
	 * @param model 数据对象
	 * @return
	 */
	@RequestMapping(value = "show.htm")
	public String get${className}(<#list table.compositeIdColumns as column>@RequestParam("${column.columnNameLower}") String ${column.columnNameLower},</#list> Model model){
		log.debug("execute  ${className}Controller get${className}");
		model.addAttribute("${classNameLower}",${classNameLower}Manager.get${className}(<#list table.compositeIdColumns as column> ${column.columnNameLower} <#if column_has_next> ,</#if> </#list>));
		return "${classNameLowerCase}/show";
	}

	/**转到添加用户界面
	 * @return 
	 */
	@RequestMapping(value = "add.htm")
	public String add${className}(){
		log.debug("execute  ${className}Controller add");
		return "${classNameLowerCase}/add";
	}
	
	/**添加用户
	 * @return json结果
	 */
	@RequestMapping(value = "save.htm")
	@ResponseBody
	public JsonResult save${className}(${className} ${classNameLower}){
		log.debug("execute  ${className}Controller save");
		//log.debug(${classNameLower}.toString());
		try{
			${classNameLower}Manager.save(${classNameLower});
		}catch(Exception e){
			return new JsonResult(false,"后台错误:"+e.getMessage());
		}
		return new JsonResult(true,"return ok");
	}
	
	/**转到用户编辑页面
	 <#list table.compositeIdColumns as column> * @param ${column.columnNameLower} ${column.columnAlias} </#list>
	 * @param model 数据对象
	 * @return
	 */
	@RequestMapping(value = "edit.htm")
	public String edit${className}(<#list table.compositeIdColumns as column>@RequestParam("${column.columnNameLower}") String ${column.columnNameLower},</#list> Model model){
		log.debug("execute  ${className}Controller edit");
		model.addAttribute("${classNameLower}",${classNameLower}Manager.get${className}(<#list table.compositeIdColumns as column> ${column.columnNameLower} <#if column_has_next> ,</#if> </#list>));
		return "${classNameLowerCase}/edit";
	}
	
	/**更新用户信息
	 * @return json结果
	 */
	@RequestMapping(value = "update.htm")
	@ResponseBody
	public JsonResult update${className}(${className} ${classNameLower}){
		log.debug("execute  ${className}Controller update");
		try{
			${classNameLower}Manager.update(${classNameLower});
		}catch(Exception e){
			return new JsonResult(false,"后台错误:"+e.getMessage());
		}
		return new JsonResult(true,"return ok");
	}
	/**删除用户
	 * @param ${classNameLower}Id 用户ID
	 * @return
	 */
	@RequestMapping(value = "delete.htm")
	@ResponseBody
	public JsonResult delete${className}(${className} ${classNameLower}){
		log.debug("execute  ${className}Controller delete");
		try{
			${classNameLower}Manager.delete(${classNameLower});
		}catch(Exception e){
			return new JsonResult(false,"后台错误:"+e.getMessage());
		}
		return new JsonResult(true,"return ok");
	}

	
	//以下为参考方法
	<#list table.columns as column>
	<#if column.unique && !column.pk>
	 /**根据${column.columnAlias}查找
	 * @param ${column.columnNameLower} ${column.columnAlias}
	 * @return 结果对象
	 */
	@RequestMapping(value = "getBy${column.columnName}.htm")
	public ${className} getBy${column.columnName}(${column.javaType} ${column.columnNameLower}){
		log.debug("execute  ${className}Controller getBy${column.columnName}");
		model.addAttribute("${classNameLower}",${classNameLower}Manager.getBy${column.columnName}(${column.columnNameLower});
		return "${classNameLowerCase}/show";
	}
	 
	</#if>
	</#list>

}