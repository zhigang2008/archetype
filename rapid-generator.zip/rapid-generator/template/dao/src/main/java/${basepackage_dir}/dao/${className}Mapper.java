<#include "/java_copyright.include">
<#assign className = table.className>   
<#assign classNameLower = className?uncap_first>   
package ${basepackage}.dao;

import java.util.List;
import ${basepackage}.model.${className};
import ${basepackage}.vo.${className}VO;
import com.htffund.etrade.sdk.base.paginator.domain.PageBounds;

<#include "/java_classdoc.include">

public interface ${className}Mapper {
	
	/**查询所有结果
	 * @return 结果列表
	 */
	public List<${className}> listAll();
	
	/**根据ID查找
	 <#list table.compositeIdColumns as column> 
	 * @param ${column.columnNameLower} ${column.columnAlias} 
	 </#list>
	 * @return 结果对象
	 */
	public ${className} getById(<#list table.compositeIdColumns as column> ${column.javaType} ${column.columnNameLower} <#if column_has_next> ,</#if> </#list>);
 
 /** 保存对象
	 * @param ${classNameLower}
	 */
	public void save(${className} ${classNameLower});
	
	/** 更新对象
	 * @param ${classNameLower}
	 * @return 更新记录数
	 */
	public int update(${className} ${classNameLower});
	
	/** 删除对象
	 * @param ${classNameLower}
	 * @return 删除记录数
	 */
	public int delete(${className} ${classNameLower});
	
	 /** 分页查询
	 * @param ${classNameLower}VO 查询参数
	 * @param pageBounds 分页参数
	 * @return 结果对象列表
	 */
	public List<${className}> pageList(${className}VO ${classNameLower}VO, PageBounds pageBounds);
	
	<#list table.columns as column>
	<#if column.unique && !column.pk>
	 /**根据${column.columnAlias}查找
	 * @param ${column.columnNameLower} ${column.columnAlias}
	 * @return 结果对象
	 */
	 public ${className} getBy${column.columnName}(${column.javaType} ${column.columnNameLower});
	 
	</#if>
	</#list>

}