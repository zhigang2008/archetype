<#include "/macro.include"/>
<#include "/java_copyright.include">
<#assign className = table.className>   
<#assign classNameLower = className?uncap_first> 
package ${basepackage}.vo;
//import org.apache.commons.lang3.builder.EqualsBuilder;
//import org.apache.commons.lang3.builder.HashCodeBuilder;
//import org.apache.commons.lang3.builder.ToStringBuilder;
//import org.apache.commons.lang3.builder.ToStringStyle;

<#include "/java_classdoc.include">

public class ${className}VO implements java.io.Serializable{
	private static final long serialVersionUID = 5454155825314635342L; //请重新生成
	
	//date formats
	<#list table.columns as column>
	<#if column.isDateTimeColumn>
	public static final String FORMAT_${column.constantName} = "yyyy-MM-dd"; // DateTime : "yyyy-MM-dd HH:mm:ss"
	</#if>
	</#list>

	<#list table.columns as column>
	/** ${column.columnAlias} */
	private ${column.javaType} ${column.columnNameLower};
  <#if column.isDateTimeColumn>
	private String ${column.columnNameLower}Begin;
	private String ${column.columnNameLower}End;	
	</#if>
	</#list>

<@generateJavaColumns/>

<#macro generateJavaColumns>
	<#list table.columns as column>
		<#if column.isDateTimeColumn>
	/*
	public String get${column.columnName}String() {
		return com.htffund.etrade.sdk.util.DateConvertUtils.format(get${column.columnName}(), FORMAT_${column.constantName});
	}
	public void set${column.columnName}String(String value) {
		set${column.columnName}(com.htffund.etrade.sdk.util.DateConvertUtils.parse(value, FORMAT_${column.constantName},${column.javaType}.class));
	}
	*/
	public String get${column.columnName}Begin() {
		return this.${column.columnNameLower}Begin;
	}
	public String get${column.columnName}End() {
		return this.${column.columnNameLower}End;
	}
	public void set${column.columnName}Begin(String ${column.columnNameLower}Begin) {
		this.${column.columnNameLower}Begin=${column.columnNameLower}Begin;
	}
	public void set${column.columnName}End(String ${column.columnNameLower}End) {
		this.${column.columnNameLower}End=${column.columnNameLower}End;
	}
	</#if>	
	public void set${column.columnName}(${column.javaType} ${column.columnNameLower}) {
		this.${column.columnNameLower} = ${column.columnNameLower};
	}
	
	public ${column.javaType} get${column.columnName}() {
		return this.${column.columnNameLower};
	}
	</#list>
</#macro>

  /*
  public String toString() {
		return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
		<#list table.columns as column>
			.append("${column.columnName}",get${column.columnName}())
		</#list>
			.toString();
	}
	
	public int hashCode() {
		return new HashCodeBuilder()
		<#list table.pkColumns as column>
			.append(get${column.columnName}())
		</#list>
			.toHashCode();
	}
	
	public boolean equals(Object obj) {
		if(obj instanceof ${className} == false) return false;
		if(this == obj) return true;
		${className} other = (${className})obj;
		return new EqualsBuilder()
			<#list table.pkColumns as column>
			.append(get${column.columnName}(),other.get${column.columnName}())
			</#list>
			.isEquals();
	}
	*/
}