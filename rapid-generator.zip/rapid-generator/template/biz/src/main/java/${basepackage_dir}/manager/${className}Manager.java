<#include "/java_copyright.include">
<#assign className = table.className>   
<#assign classNameLower = className?uncap_first>   
package ${basepackage}.manager;

import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import ${basepackage}.dao.${className}Mapper;
import ${basepackage}.manager.${className}Manager;
import ${basepackage}.model.${className};
import ${basepackage}.vo.${className}VO;
import com.htffund.etrade.sdk.base.paginator.domain.PageBounds;

<#include "/java_classdoc.include">

@Service("${classNameLower}Manager")
public class ${className}Manager {
	/**logger*/
	static final Logger log = LogManager.getLogger(${className}Manager.class.getName());
	
	@Autowired
	private ${className}Mapper ${classNameLower}Mapper;

  /**��ѯ���н��
	 * @return ����б�
	 */
	public List<${className}> listAll(){
		return ${classNameLower}Mapper.listAll();
	}
	
	/**����ID����
	 <#list table.compositeIdColumns as column> 
	 * @param ${column.columnNameLower} ${column.columnAlias} 
	 </#list>
	 * @return �������
	 */
	public ${className} get${className}(<#list table.compositeIdColumns as column> ${column.javaType} ${column.columnNameLower} <#if column_has_next> ,</#if> </#list>){
		return ${classNameLower}Mapper.getById(<#list table.compositeIdColumns as column> ${column.columnNameLower} <#if column_has_next> ,</#if> </#list>);
	}

	/** �������
	 * @param ${classNameLower}
	 */
	public void save(${className} ${classNameLower}) {
		${classNameLower}Mapper.save(${classNameLower});
		
	}

	/** ���¶���
	 * @param ${classNameLower}
	 * @return ���¼�¼��
	 */
	public int update(${className} ${classNameLower}) {
		return ${classNameLower}Mapper.update(${classNameLower});
		
	}

	/** ɾ������
	 * @param ${classNameLower}
	 * @return ɾ����¼��
	 */
	public int delete(${className} ${classNameLower}) {
		return ${classNameLower}Mapper.delete(${classNameLower});

	}

	/** ��ҳ��ѯ
	 * @param ${classNameLower}VO ��ѯ����
	 * @param pageBounds ��ҳ����
	 * @return ��������б�
	 */
	public List<${className}> pageList(${className}VO ${classNameLower}VO, PageBounds pageBounds) {
		List<${className}> list= ${classNameLower}Mapper.pageList(${classNameLower}VO,pageBounds);
		return  list;
		
	}
	
	<#list table.columns as column>
	<#if column.unique && !column.pk>
	/**����${column.columnAlias}����
	 * @param ${column.columnNameLower} ${column.columnAlias}
	 * @return �������
	 */
	public ${className} getBy${column.columnName}(${column.javaType} ${column.columnNameLower}){
		return ${classNameLower}Mapper.getBy${column.columnName}(${column.columnNameLower});
	}
	
	</#if>
	</#list>
	
}
