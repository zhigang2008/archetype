<#include "/java_copyright.include">
<#assign className = table.className>   
<#assign classNameLower = className?uncap_first>   
package ${basepackage}.manager.impl;

import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import ${basepackage}.dao.${className}Mapper;
import ${basepackage}.manager.${className}Manager;
import ${basepackage}.model.${className};
import ${basepackage}.vo.${className}VO;
import com.htffund.etrade.sdk.base.paginator.domain.PageBounds;

<#include "/java_classdoc.include">

@Service("${classNameLower}Manager")
public class ${className}ManagerImpl implements ${className}Manager {
	/**logger*/
	static final Logger log = LogManager.getLogger(${className}ManagerImpl.class.getName());
	
	@Autowired
	private ${className}Mapper ${classNameLower}Mapper;

  /* (non-Javadoc)
	 * @see ${basepackage}.manager.${className}Manager#listAll()
	 */
	public List<${className}> listAll(){
		return ${classNameLower}Mapper.listAll();
	}
	
	/* (non-Javadoc)
	 * @see ${basepackage}.manager.${className}Manager#get${className}(<#list table.compositeIdColumns as column> ${column.javaType} ${column.columnNameLower} <#if column_has_next> ,</#if> </#list>)
	 */
	public ${className} get${className}(<#list table.compositeIdColumns as column> ${column.javaType} ${column.columnNameLower} <#if column_has_next> ,</#if> </#list>){
		return ${classNameLower}Mapper.getById(<#list table.compositeIdColumns as column> ${column.columnNameLower} <#if column_has_next> ,</#if> </#list>);
	}

	/* (non-Javadoc)
	 * @see ${basepackage}.manager.${className}Manager#save(${basepackage}.model.${className})
	 */
	public void save(${className} ${classNameLower}) {
		${classNameLower}Mapper.save(${classNameLower});
		
	}

	/* (non-Javadoc)
	 * @see ${basepackage}.manager.${className}Manager#update(${basepackage}.model.${className})
	 */
	public int update(${className} ${classNameLower}) {
		return ${classNameLower}Mapper.update(${classNameLower});
		
	}

	/* (non-Javadoc)
	 * @see ${basepackage}.manager.${className}Manager#delete(java.lang.String)
	 */
	public int delete(${className} ${classNameLower}) {
		return ${classNameLower}Mapper.delete(${classNameLower});

	}

	/* (non-Javadoc)
	 * @see ${basepackage}.manager.${className}Manager#pageList(${basepackage}.vo.${className}VO, com.htffund.etrade.sdk.base.paginator.domain.PageBounds)
	 */
	public List<${className}> pageList(${className}VO ${classNameLower}VO, PageBounds pageBounds) {
		List<${className}> list= ${classNameLower}Mapper.pageList(${classNameLower}VO,pageBounds);
		return  list;
		
	}
	
	<#list table.columns as column>
	<#if column.unique && !column.pk>
	public ${className} getBy${column.columnName}(${column.javaType} ${column.columnNameLower}){
		return ${classNameLower}Mapper.getBy${column.columnName}(${column.columnNameLower});
	}
	
	</#if>
	</#list>
	
}
